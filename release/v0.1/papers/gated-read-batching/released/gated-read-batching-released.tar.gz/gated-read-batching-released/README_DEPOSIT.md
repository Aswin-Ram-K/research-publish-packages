# gated-read-batching — released data and verification tooling

## What this is

This is the **released data and verification tooling** for the note

> *Cheap batches, weak gate: batching binary read-gate decisions 16–90-way at `effort=none` does not
> measurably degrade them, and a purpose-conditioned read gate on header and structure alone is not yet
> a classifier*

by **Aswin Ram Kalugasala Moorthy** (2026). It is the deposit-level front matter for the archive; the
per-directory detail lives in `README.md`, `MANIFEST.json` and `results/GATED_READ_2026.md`.

**Concept DOI `10.5281/zenodo.23483314`.** `CITATION.cff` carries that concept DOI in its `doi` field. The concept DOI is
declared rather than a version DOI because it always resolves to the latest version. *Superseded, dated
2026-10-19 and kept as dated history:* this paragraph previously stated that no DOI had been minted and
that `CITATION.cff` therefore carried no `doi` field until the author added one.

## What this is not

- **The harness, the corpus and the task fixture are withheld.** There is no `harness/` or
  `tools/gated-read/` directory, no 90-file corpus, no `tasks.json` and no model service. The gate
  decisions were produced by a small decision model served outside this package; nothing here can
  produce another one.
- **The checks here do not retrain or re-render anything.** They re-derive the published numbers
  **from the stored records** in this package. They read bytes that ship with the deposit; they do not
  regenerate a model input, run an arm, or re-run the measurement.
- **This is not a reproduction package.** A reader cannot retrain the decision model, cannot
  reconstruct the 1,800 (task, file) pairs, and cannot re-run the batching comparison from this deposit
  alone. What is verifiable here is that the shipped records are internally consistent with the
  published numbers.
- **The stored gold labels cannot be rebuilt from anything in this package — a validity limitation,
  not a bookkeeping one.** Re-deriving the gold set from corpus content under the rule the fixture
  states yields **127 gold pairs in the pinned snapshot tree and 130 in the live tree, against 120
  stored**; 10 of the 12 stored-only pairs are a single file, `AGENTS.md`. No harness or fixture script
  reproducing the stored `gold` field exists on disk, and `tasks.json` lists 90 paths with no hashes.
  The **120-pair gold count**, the **6.7 % base rate** and every precision, recall, F1 and accuracy
  figure are therefore obtained from *recorded verdicts*, not reproduced from the fixture. The batching
  comparison is not endangered — all five configurations share the same stored labels — but the numbers
  describe label-consistent behaviour rather than an independently reproducible fixture. Full text:
  the package `README.md` and `GAPS.md` gap G-25.
- **This is not the paper text.** The note is a separate work under **CC BY 4.0**.

## What ships

| path | contents |
|---|---|
| `data/gated-read-rows.jsonl` | the 9,260 per-decision rows the recomputation reads — the proven-minimal closure (2,267,742 B) |
| `results/gated-read-summary.json` | the aggregates the harness wrote |
| `results/GATED_READ_2026.md` | the run report (340 lines) |
| `results/GATED_READ_PROVENANCE.md` | literature provenance and fetched URLs |
| `verify/recompute-claims.py` | re-derives every headline number from `data/` alone; standard library only |
| `README.md`, `LICENSE`, `COMMERCIAL.md`, `CONTRIBUTING.md`, `MANIFEST.json` | package documentation, licence, commercial terms, contribution terms, integrity manifest |
| `CITATION.cff` | deposit-level citation (deposit metadata; not package content) |
| `README_DEPOSIT.md` | this deposit-level front matter (deposit metadata; not package content) |

**The shipped records are not byte-identical to the source tree they were cut from, and the difference is bounded and disclosed.** Six `answer` values in `data/gated-read-rows.jsonl` (four R5 trace identifiers, two uppercase target-project sentinels) and one prose word in `results/GATED_READ_2026.md` were replaced, at equal length, by neutral identifiers, so every byte count and line count — and every published number — is unchanged. The full list, with superseded digests, is in the package `README.md` and `CLAIMS.md` claim R; the row-level rename is tracked as gap G-23 (`GAPS.md`), now closed.

## How to use it — the exact check and its expected output

Standard-library-only Python 3; no third-party dependencies, no network, no GPU. Run from the top of the
extracted directory (the directory holding `verify/`).

```bash
python3 verify/recompute-claims.py
```

Expected: **exit status `0`**. The tail of the output reads

```
checks: 49   passed: 49   failed: 0
VERDICT: PASS -- every published number reproduced from the shipped bytes
```

Above that it prints one line per comparison: the per-`mode` `ptok`/`ctok` sums, the `tp`/`fp`/`fn`
counts, precision/recall/F1, admitted pairs, tokens per decision, row and error counts, the stored
120-pair gold count, the 6.7 % base rate, and the sha256 of the shipped rows. **Every comparison is
folded into the exit status**; any `[FAIL]` makes it exit `1` and names the claim that failed.

**Two checks are labelled `RUN-REPORT-ONLY` and are not manuscript claims:** the 15.279×
selfselect/stage_route prompt-token ratio and the exposure 0/20 for `stage_route`. `MANUSCRIPT.md:195`
scopes the end-to-end / injection-exposure arm out of the note; they are re-derived here because the
package was contracted to re-derive them, and a reader must not read them as published numbers.

**What the checker does not recompute**, and says so: the corpus-scale numbers (90 files;
2,426,190 B pinned / 2,886,664 B live) and the literature numbers are stated from the run report only —
the corpus and the batching literature are not in this package, and `tasks.json` has no size or hash
fields. The run report's recorded **"1.83 MB" is withdrawn** as unsupported (`GAPS.md` G-25).

## Licence

The released artifacts — everything in this directory — are **source-available under the PolyForm
Noncommercial License 1.0.0** (see `LICENSE`), with a **paid commercial licence offered directly by the
author** (see `COMMERCIAL.md`). The PolyForm Noncommercial licence does not cover commercial use and
grants no commercial right. The **note is separately licensed CC BY 4.0**. The main project repository
remains **proprietary and closed**; nothing in this deposit is a grant of rights in it, and the terms
above grant **no rights in the withheld harness**.

## Integrity — what `MANIFEST.json` covers, and what it does not

**Package content vs deposit metadata.** The released *package* is **10 files**. The deposit *archive*
wraps that package in a single top-level directory and adds exactly **2 deposit-metadata files** on top
of it — `CITATION.cff` (the deposit-level citation) and this file, `README_DEPOSIT.md`. The archive
therefore ships **12 files**. Those two files are the **only** files in the archive that are not package
content; every one of the other 10 is byte-identical to the package. `README.md` is the package's own
README and ships unchanged; `README_DEPOSIT.md` and `CITATION.cff` were added on top of it for the
deposit.

**The tree carries one manifest, regenerated after the deposit extras were added.** There is no second
shipped tree: the manifest that ships describes the 12-file tree it sits in. It enumerates **11**
entries — the package's 9 non-self entries plus `CITATION.cff` and `README_DEPOSIT.md` — and does not
enumerate itself, because a self-referential sha256 is impossible. `counts.files` **includes**
`MANIFEST.json` (`12`) while `counts.bytes_total` **excludes** its own bytes. The same self-exemption
convention applies in the author-side package manifest (`counts.files = 10`, 9 entries).

Check the manifest at the top of the **extracted archive** (a reader has no other copy):

```bash
python3 - <<'PY'
import hashlib, json, os
m = json.load(open("MANIFEST.json"))
bad = []
for e in m["files"]:
    h = hashlib.sha256(open(e["path"], "rb").read()).hexdigest()
    if h != e["sha256"] or os.path.getsize(e["path"]) != e["bytes"]:
        bad.append(e["path"])
print("MANIFEST checked:", len(m["files"]), "files; mismatches:", bad or "none")
PY
```

Expected: `MANIFEST checked: 11 files; mismatches: none`.

**Independent checker (author-side; not shipped).** The author's independent checker re-hashes every
listed path and walks the tree for files the manifest omitted; it exits non-zero if any of `missing`,
`hash_mismatch`, `size_mismatch`, `unlisted`, `listed_but_absent` is non-zero. It is author-side build
tooling and does not ship, so it cannot be run from the archive; the inline re-hash above is the shipped
equivalent for a reader. The author ran it on the payload tree and on the extracted archive; both
reported `missing=0 hash_mismatch=0 size_mismatch=0 unlisted=0 listed_but_absent=0` and `VERDICT PASS`,
exit `0`.

### How the archive is assembled (the ordering that makes this true)

1. Stage the package's 10 files into `<stage>/gated-read-batching-released/`.
2. Add the 2 deposit extras — `CITATION.cff` and `README_DEPOSIT.md` (this file) — to the stage.
3. **Regenerate `MANIFEST.json` in the stage**, with the project's manifest generator (author-side
   tooling that does not ship; invoked with `--no-note --generated-utc <pinned>`). It now describes
   12 files. It is regenerated again in each build, from
   the tree as it stands, so the manifest always describes the tree that ships.
4. Pack deterministically, twice, and compare:
   `tar --format=gnu --sort=name --owner=0 --group=0 --numeric-owner --mtime=@0 -C <stage> -cf -
   gated-read-batching-released | gzip -n -9 > gated-read-batching-released.tar.gz`.

Step 3 after step 2 is the whole point: the archive's manifest is generated from the archive's own tree,
after that tree exists. The author-side package's `MANIFEST.json` is never written by this step and
keeps describing the 10-file package.
