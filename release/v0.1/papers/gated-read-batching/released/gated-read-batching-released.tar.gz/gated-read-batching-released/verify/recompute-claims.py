#!/usr/bin/env python3
"""verify/recompute-claims.py -- re-derive every headline number of paper #7 from the shipped bytes.

ONE PURPOSE: show that the published numbers survive in a package that ships only the per-decision
rows (plus the run report and summary as records), with no harness, no corpus and no task fixture.

WHAT IS RECOMPUTED HERE. All manuscript headline numbers are re-derived from
`data/gated-read-rows.jsonl` alone: the per-`mode` `ptok`/`ctok` sums, the `tp`/`fp`/`fn` counts,
precision/recall/F1, admitted pairs, tokens/decision, row and error counts, the stored 120-pair gold
count and the 6.7 % base rate, and the byte digest of the shipped records.

WHAT IS NOT RECOMPUTED HERE. The corpus-scale claims (90 files; 2.426 MB pinned / 2.753 MB live;
the withdrawn "1.83 MB") and the literature numbers cannot be recomputed from these bytes -- the
corpus and the provenance of the batching literature are not in this package, and `tasks.json` has
no size or hash fields. They are stated in `README.md` and `results/GATED_READ_2026.md`, not
machine-checked here. The stored gold labels are NOT reproducible from the corpus: see the validity
limitation in `README.md`.

TWO LABELS ON THE CHECKS, because they do not have the same standing:
  * `MANUSCRIPT` -- printed in the note (a separate work; not part of this deposit).
  * `RUN-REPORT-ONLY` -- printed in `results/GATED_READ_2026.md` (R5), and explicitly NOT claimed in
    the manuscript, which scopes the end-to-end / injection-exposure arm out of the paper
    (MANUSCRIPT.md:195). They are enforced here because this packager was contracted to re-derive
    them; a reader must not read them as manuscript numbers.

EVERY comparison is folded into the exit status: one MISMATCH makes the process exit 1. (Paper #3's
checker once printed `reproduced=False` and still exited 0; that failure mode is not repeated.)

Usage:
  python3 verify/recompute-claims.py                 # reads this package, from anywhere
  python3 verify/recompute-claims.py --tree <DIR>    # read another tree (used for the cut ladder)
Standard library only.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DEF_TREE = os.path.dirname(HERE)

# The digest of the shipped records (CLAIMS.md R: 2,267,742 bytes, 9,260 lines). Superseded values:
# the pre-2026-10-19 source-tree copy 5732766d67d533a2b2e2ddce50d04bcb34a2480f70e1087fdee5754cacc35223, and the 2026-10-19
# pass-1 copy b063fbae534a8e5f6649e6b36a21f12b2c40f95c8b0a36b290ad1adf650de809, and the 2026-10-19 pass-2 copy
# bc2b2a5a36f331a621437cdf328d0d77 / e877d05e.... The shipped copy differs from the pinned source tree only in six R5 `answer`
# values (passes 1-2) and one prose word in results/GATED_READ_2026.md (pass 3), all neutralised at equal length, so the byte
# and line counts are unchanged.
ROWS_SHA256 = "184ab747e87f7d127005ce08316dcde640ae93e5278bb1bd57bf353e23d9c44f"
GATE_MODES = ("gate1_none", "gate16_none", "gate90_none", "gate1_minimal", "gate90_minimal")

_results = []


def chk(name: str, published, got, tol: float, cite: str) -> None:
    ok = got is not None and abs(float(got) - float(published)) <= tol
    _results.append(ok)
    print(f"  [{'OK  ' if ok else 'FAIL'}] {name:44s} published={published!r:<18} "
          f"recomputed={got!r:<22} {cite}")


def chk_str(name: str, published: str, got: str, cite: str) -> None:
    ok = published == got
    _results.append(ok)
    print(f"  [{'OK  ' if ok else 'FAIL'}] {name:44s} published={published[:16]!r:<18} "
          f"recomputed={got[:16]!r:<22} {cite}")


def ratio(a: float, b: float) -> float:
    return a / b


def f1_of(tp: int, fp: int, fn: int) -> float:
    p = tp / (tp + fp) if (tp + fp) else 0.0
    r = tp / (tp + fn) if (tp + fn) else 0.0
    return 2 * p * r / (p + r) if (p + r) else 0.0


def main() -> int:
    ap = argparse.ArgumentParser(description="recompute paper #7 headline numbers from shipped bytes")
    ap.add_argument("--tree", default=DEF_TREE, help="package tree to read (default: this package)")
    a = ap.parse_args()
    root = os.path.abspath(a.tree)
    rows_path = os.path.join(root, "data", "gated-read-rows.jsonl")
    if not os.path.isfile(rows_path):
        sys.stderr.write(f"FATAL: no {rows_path}\n")
        return 2
    raw = open(rows_path, "rb").read()
    rows = [json.loads(ln) for ln in raw.decode("utf-8").splitlines() if ln.strip()]

    pt = collections.defaultdict(int)
    ct = collections.defaultdict(int)
    n = collections.Counter()
    tp = collections.Counter()
    fp = collections.Counter()
    fn = collections.Counter()
    gold = collections.Counter()
    errs = 0
    unparsed = 0
    for r in rows:
        m = r.get("mode")
        n[m] += 1
        pt[m] += r.get("ptok") or 0
        ct[m] += r.get("ctok") or 0
        if r.get("err") is not None:
            errs += 1
        if m in GATE_MODES:
            g, p = r.get("gold"), r.get("pred")
            if g:
                gold[m] += 1
            if p is None:
                unparsed += 1
            elif p and g:
                tp[m] += 1
            elif p and not g:
                fp[m] += 1
            elif (not p) and g:
                fn[m] += 1

    print(f"tree: {root}")
    print(f"records read: {len(rows)}   sha256={hashlib.sha256(raw).hexdigest()}")
    print(f"modes: {dict(sorted(n.items()))}")

    # `calls` is not a row: it is the number of (task, batch) groups recorded in the `tag` field.
    # gate16/gate90 tags carry a "<batch>:" prefix, gate1 tags do not. Dropping `task`/`tag`
    # therefore breaks the calls column -- proved by the cut ladder, and the reason those two
    # columns are load-bearing even though CLAIMS.md's one-line recompute rule never names them.
    calls = {}
    for m in GATE_MODES:
        rs = [r for r in rows if r.get("mode") == m]
        calls[m] = (len({(r["task"], r["tag"].split(":")[0]) for r in rs})
                    if all("task" in r and "tag" in r for r in rs) else None)

    # ---- the byte-identity of the shipped record ------------------------------------------------
    print("\nSHIPPED RECORD")
    chk_str("rows_sha256", ROWS_SHA256, hashlib.sha256(raw).hexdigest(), "CLAIMS.md R")
    chk("rows_total", 9260, len(rows), 0, "CLAIMS.md C26")
    chk("gate_rows_total", 9000, sum(n[m] for m in GATE_MODES), 0, "MANUSCRIPT.md:137")
    chk("pairs_per_config", 1800, max(n[m] for m in GATE_MODES), 0, "MANUSCRIPT.md:85")
    for m in GATE_MODES:
        chk(f"pairs[{m}]", 1800, n[m], 0, "MANUSCRIPT.md:85")
    chk("gold_pairs_per_config", 120, max(gold[m] for m in GATE_MODES), 0, "MANUSCRIPT.md:85")
    chk("base_rate", 0.0667, gold["gate1_none"] / n["gate1_none"], 5e-5, "MANUSCRIPT.md:85")
    chk("errors_total", 0, errs, 0, "MANUSCRIPT.md:99")
    chk("unparsed_gate_rows", 0, unparsed, 0, "MANUSCRIPT.md:99")

    # ---- R2 batching: prompt tokens, calls, F1 --------------------------------------------------
    print("\nR2 BATCHING (effort=none)")
    chk("prompt_tok[gate1_none]", 631210, pt["gate1_none"], 0, "MANUSCRIPT.md:137")
    chk("prompt_tok[gate16_none]", 269614, pt["gate16_none"], 0, "MANUSCRIPT.md:137")
    chk("prompt_tok[gate90_none]", 261090, pt["gate90_none"], 0, "MANUSCRIPT.md:137")
    chk("prompt_tok_ratio_16", 2.341, ratio(pt["gate1_none"], pt["gate16_none"]), 1e-3, "MANUSCRIPT.md:137")
    chk("prompt_tok_ratio_90", 2.418, ratio(pt["gate1_none"], pt["gate90_none"]), 1e-3, "MANUSCRIPT.md:137")
    chk("calls[gate1_none]", 1800, calls["gate1_none"], 0, "MANUSCRIPT.md:137")
    chk("calls[gate16_none]", 120, calls["gate16_none"], 0, "MANUSCRIPT.md:137")
    chk("calls[gate90_none]", 20, calls["gate90_none"], 0, "MANUSCRIPT.md:137")
    chk("calls[gate1_minimal]", 1800, calls["gate1_minimal"], 0, "MANUSCRIPT.md:153")
    chk("calls[gate90_minimal]", 20, calls["gate90_minimal"], 0, "MANUSCRIPT.md:153")
    chk("f1[gate1_none]", 0.2176, f1_of(tp["gate1_none"], fp["gate1_none"], fn["gate1_none"]), 5e-4, "MANUSCRIPT.md:137")
    chk("f1[gate16_none]", 0.2268, f1_of(tp["gate16_none"], fp["gate16_none"], fn["gate16_none"]), 5e-4, "MANUSCRIPT.md:137")
    chk("f1[gate90_none]", 0.2105, f1_of(tp["gate90_none"], fp["gate90_none"], fn["gate90_none"]), 5e-4, "MANUSCRIPT.md:137")
    f1s = {m: f1_of(tp[m], fp[m], fn[m]) for m in ("gate1_none", "gate16_none", "gate90_none")}
    chk("f1_spread_none", 0.0163, max(f1s.values()) - min(f1s.values()), 5e-4, "MANUSCRIPT.md:137")

    # ---- the operating point F1 hides -----------------------------------------------------------
    print("\nOPERATING POINT (admits = tp + fp)")
    chk("tp[gate1_none]->[gate16_none]", 23, tp["gate16_none"] - tp["gate1_none"], 0, "MANUSCRIPT.md:143")
    chk("fp[gate1_none]->[gate16_none]", 172, fp["gate16_none"] - fp["gate1_none"], 0, "MANUSCRIPT.md:143")
    chk("recall[gate1_none]", 0.1750, tp["gate1_none"] / gold["gate1_none"], 5e-4, "MANUSCRIPT.md:143")
    chk("recall[gate1_minimal]", 0.3667, tp["gate1_minimal"] / gold["gate1_minimal"], 5e-4, "MANUSCRIPT.md:143")
    for m, want in (("gate1_none", 73), ("gate16_none", 268), ("gate90_none", 146)):
        chk(f"admitted[{m}]", want, tp[m] + fp[m], 0, "MANUSCRIPT.md:143")

    # ---- minimal effort: the cost of thinking ---------------------------------------------------
    print("\nMINIMAL EFFORT (bs90 vs bs1)")
    chk("completion_tok[gate90_minimal]", 1690920, ct["gate90_minimal"], 0, "MANUSCRIPT.md:147")
    chk("completion_tok_ratio_bs90_over_bs1", 8.866,
        ratio(ct["gate90_minimal"], ct["gate1_minimal"]), 5e-2, "MANUSCRIPT.md:147")
    chk("total_tok[gate90_minimal]", 1952010, pt["gate90_minimal"] + ct["gate90_minimal"], 0, "MANUSCRIPT.md:147")
    chk("tok_per_decision[gate90_minimal]", 1084.45,
        (pt["gate90_minimal"] + ct["gate90_minimal"]) / n["gate90_minimal"], 0.5, "MANUSCRIPT.md:147")
    chk("tok_per_decision[gate1_minimal]", 456.6,
        (pt["gate1_minimal"] + ct["gate1_minimal"]) / n["gate1_minimal"], 0.5, "CLAIMS.md C31")
    chk("tok_per_decision_ratio", 2.375,
        ratio((pt["gate90_minimal"] + ct["gate90_minimal"]) / n["gate90_minimal"],
              (pt["gate1_minimal"] + ct["gate1_minimal"]) / n["gate1_minimal"]), 5e-2, "MANUSCRIPT.md:147")
    chk("f1[gate1_minimal]", 0.3200, f1_of(tp["gate1_minimal"], fp["gate1_minimal"], fn["gate1_minimal"]), 5e-4, "MANUSCRIPT.md:147")
    chk("f1[gate90_minimal]", 0.2995, f1_of(tp["gate90_minimal"], fp["gate90_minimal"], fn["gate90_minimal"]), 5e-4, "MANUSCRIPT.md:147")
    chk("precision[gate90_minimal]", 0.4179,
        tp["gate90_minimal"] / (tp["gate90_minimal"] + fp["gate90_minimal"]), 5e-4, "MANUSCRIPT.md:165")
    chk("recall[gate90_minimal]", 0.2333, tp["gate90_minimal"] / gold["gate90_minimal"], 5e-4, "MANUSCRIPT.md:165")
    chk("effort_cost_ratio_gate1_min_over_none", 1.280,
        ratio(pt["gate1_minimal"] + ct["gate1_minimal"], pt["gate1_none"] + ct["gate1_none"]), 5e-3, "CLAIMS.md C44")

    # ---- R5: out-of-scope arm re-derived from the same rows --------------------------------------
    # RUN-REPORT-ONLY. MANUSCRIPT.md:195 explicitly makes no claim about this arm.
    print("\nR5 END-TO-END / EXPOSURE (RUN-REPORT-ONLY -- NOT claimed in MANUSCRIPT.md:195)")
    e2e = collections.defaultdict(list)
    for r in rows:
        if r.get("mode") == "e2e":
            e2e[r.get("arm")].append(r)
    ss, sr = e2e["selfselect"], e2e["stage_route"]
    ss_tok = sum(r["ptok"] for r in ss) / len(ss)
    sr_tok = sum(r["ptok"] for r in sr) / len(sr)
    chk("e2e_prompt_tok_ratio_selfselect/stage_route", 15.279, ratio(ss_tok, sr_tok), 1e-2,
        "GATED_READ_2026.md:206")
    chk("e2e_exposure_stage_route", 0, sum(1 for r in sr if r.get("ctx_has_a") or r.get("ctx_has_b")), 0,
        "GATED_READ_2026.md:199")
    chk("e2e_exposure_stage_route_n", 20, len(sr), 0, "GATED_READ_2026.md:199")
    chk("e2e_exposure_selfselect", 20, sum(1 for r in ss if r.get("ctx_has_a") or r.get("ctx_has_b")), 0,
        "GATED_READ_2026.md:196")

    ok = all(_results)
    print(f"\nchecks: {len(_results)}   passed: {sum(_results)}   failed: {len(_results) - sum(_results)}")
    print("VERDICT:", "PASS -- every published number reproduced from the shipped bytes" if ok else
          "FAIL -- at least one published number does not match the shipped bytes (rows above)")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
