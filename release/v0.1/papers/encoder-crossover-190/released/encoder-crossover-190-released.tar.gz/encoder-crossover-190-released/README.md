# Encoder-crossover-190 -- data + verification tools

## What ships

| bucket | contents |
|---|---|
| `fixture/` | the 190-case decision instrument (`fixture-190.json`), its TypeScript source (`reflex-decisions.ts`) and case schema (`DECISION_CASE_SCHEMA.ts`) |
| `results/` | the frozen per-arm evaluation records and `REPORT.md` -- the published numbers |
| `verify/` | `recompute-claims.py` -- recomputes every headline number from the bytes in this package |
| `second-labeller/` | the independent second-labelling tooling (`parse_fixture.py`, `compare.py`), labels, and metrics |
| `preregistration/` | the pre-registration |

## What is withheld

**The harness implementation does not ship.** There is no `harness/` directory. The collection,
preparation, training, evaluation, analysis and linting code, and the harness's own data files
(`corpus.json`, `dev.jsonl`, `train.jsonl`, `lint-report.json`, `manifest.json`), are deliberately
excluded. The one harness data file the verification path needs -- the 190-case fixture -- has been
relocated to `fixture/fixture-190.json` and the single reading site in `verify/recompute-claims.py`
patched accordingly. Deleting the whole `harness/` directory therefore costs no number and breaks no
tool; this was tested, not assumed.

## How to verify

```bash
python3 verify/recompute-claims.py                 # exit 0 == all claim numbers preserved
python3 second-labeller/parse_fixture.py           # regenerates cases.json etc. from the fixture
python3 second-labeller/compare.py                 # route A / route B metrics + AB agreement
```

All three scripts are standard-library-only Python 3.
