/**
 * Neutralised decision fixture (NEUTRAL-TAG/v1).
 *
 * Code-agnostic extraction: every project-level identifier has been replaced by an opaque
 * tag, and the surrounding machinery is presented as a generic placeholder architecture.
 * The scored fields (case id, question text, option text, correct index) are preserved
 * verbatim, because the published numbers are a function of them.
 *
 * Provenance and integrity digests are recorded in the release report that accompanies this
 * package. No tag-to-original mapping ships with this file.
 */

export type S12 =
  | "K02"
  | "N10"
  | "K05"
  | "K07"
  | "K01"
  | "K04"
  | "K03";

export interface S02 {
  id: string;
  kind: S12;
  /** The question as it would be put to the model. Must be self-contained. */
  question: string;
  /** The 2-8 (never more) options, as short semantic labels. */
  options: string[];
  /** Index into options. Exactly one correct answer. */
  correct: number;
  /** Why the correct answer is correct — used in review, not fed to the model. */
  rationale: string;
  /** Withheld in this sanitised release. */
  namespaces: string[];
}

export const S07: readonly S02[] = [
  /* ==================================================================== */
  /* [withheld: section note naming internal mechanism — see the withheld rationale note, section 3] */
  /* [withheld: section note naming internal mechanism — see the withheld rationale note, section 3] */
  /* F07 false) and R11 (R07, C06+C02).  */
  /* Catalogued classes used below declare their grant sets in the         */
  /* question, so each label follows from the stated policy.               */
  /* ==================================================================== */

  {
    id: "N01-001",
    kind: "K02",
    question:
      "Step 3 must emit a written critique of the diff already recorded under the execution namespace. It reads nothing from the workspace and writes nothing; its entire output is the proposal payload. The catalogue holds exactly the two native classes: G16 (layer NC18, POLICY_A kind 'none') and G28 (layer G14, POLICY_A kind 'declared' with tools NC08 and NC05). Which TYPE_A runs this step?",
    options: ["G16 (propose only)", "G28 (G14, writes)"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-002",
    kind: "K02",
    question:
      "Step 2 must apply an already-admitted patch to module.ts inside the granted workspace so the on-disk digest changes before the G18 runs. No reading and no reasoning beyond applying the patch is required. Which TYPE_A runs this step?",
    options: ["G16 (propose only)", "G28 (G14, writes)"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-003",
    kind: "K02",
    question:
      "Step 4 must report whether the A3_budget gate in MODULE_5 delegates on pass, by reading that file's current contents out of the workspace. The step changes no file and its whole output is a report. The catalogue holds G16 (NC18, POLICY_A 'none') and NC17 (NC18, POLICY_A 'none'). Which TYPE_A runs this step?",
    options: ["G16 (propose only)", "G28 (G14, writes)", "NC17 (NC18 judge)"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-004",
    kind: "K02",
    question:
      "One step must apply a write patch and a following step must run the unit suite. No single catalogued class declares both NC05 and NC11. The planner's rule is one class per step, and the step boundary is where capability changes. Which TYPE_A runs the first of the two steps?",
    options: ["G28 (G14, writes)", "G18 (G15, NC11)", "no class fits"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-005",
    kind: "K02",
    question:
      "Step 5 must append exactly one record to the memory module through a NC12 tool and must not touch any workspace file. G28's declared tools are exactly NC08 and NC05. The catalogue also holds NC15 (layer G15, POLICY_A declared with tool NC12). Which TYPE_A runs this step?",
    options: ["G16 (propose only)", "G28 (G14, writes)", "NC15 (G15, NC12)"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-006",
    kind: "K02",
    question:
      "A proposal has arrived whose declared spend would exceed the state's budget envelope, so the A3_budget gate refuses it. The refusal must be recorded as a new state carrying the reason and the offending gate. Which TYPE_A runs the step that records it?",
    options: ["G16 (propose only)", "G28 (G14, writes)", "none -- G25) mints the state"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-007",
    kind: "K02",
    question:
      "Two versions of G28 are registered: 1.0.0 and 1.1.0. The head state references G28@1.0.0 by content hash, and replay from that state must reproduce the recorded path exactly. Which TYPE_A runs the next step?",
    options: ["G28@1.0.0 (the referenced hash)", "G28@1.1.0 (the newest)", "G28@1.1.0 (patch compatible)"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-008",
    kind: "K02",
    question:
      "A step must read workspace/MODULE_4 and return a verdict on it, and the postcondition explicitly forbids writing. The planner's rule is to select the class whose declared grant set is the smallest set that can satisfy the postconditions. The catalogue holds NC16 (G15, declared tools ['NC08']), G16 (NC18, no tools) and G28 (G14, declared tools ['NC08','NC05']). Which TYPE_A runs it?",
    options: ["NC16 (G15, NC08)", "G16 (propose only)", "G28 (G14, writes)"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-009",
    kind: "K02",
    question:
      "A step must run the test suite and record its exit code, and no file may change. The catalogue holds G18 (G15, declared tools ['NC11']) and G28 (G14, declared tools ['NC08','NC05']); the planner's rule is the smallest declared grant set that satisfies the postconditions. Which TYPE_A runs it?",
    options: ["G18 (G15, NC11)", "G28 (G14, writes)", "no class reaches it"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-010",
    kind: "K02",
    question:
      "Step 1 of a task must emit a three-item plan naming the classes that should follow, and must not touch the workspace or produce any artifact. Which TYPE_A runs it?",
    options: ["G16 (propose only)", "G28 (G14, writes)", "no class -- engine only"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-011",
    kind: "K02",
    question:
      "A step must write one file into the granted workspace and then stop; the postcondition is the file's existence and content hash, and nothing else is required. Which TYPE_A runs it?",
    options: ["G16 (propose only)", "G28 (G14, writes)"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-012",
    kind: "K02",
    question:
      "A step must restate the task in one sentence using only what the current projection already carries, and must read and write nothing. Which TYPE_A runs it?",
    options: ["G16 (propose only)", "G28 (G14, writes)"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-013",
    kind: "K02",
    question:
      "A step must update one G03 record in the memory module to reflect a method that has just proved reliable, and must touch neither the workspace nor the knowledge module. NC15 is the catalogued class that declares NC12; G28 declares only NC08 and NC05. Which TYPE_A runs it?",
    options: ["G16 (propose only)", "G28 (G14, writes)", "NC15 (G15, NC12)"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-014",
    kind: "K02",
    question:
      "A step must read workspace/MODULE_1 and write a sibling file workspace/MODULE_7 that exercises it. Both halves are required. The catalogue holds G16 (NC18, no tools), NC16 (G15, ['NC08']) and G28 (G14, ['NC08','NC05']); the planner's rule is the smallest declared grant set that satisfies the postconditions. Which TYPE_A runs it?",
    options: ["G28 (G14, writes)", "NC16 (G15, NC08)", "two steps, one class each"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-015",
    kind: "K02",
    question:
      "A step must write a file through an attachment point inside the sandbox, and the only class that declares a write grant for it is declared layer 'G15'. Which TYPE_A runs it?",
    options: ["the G15 class as declared", "G28 (G14, writes)", "none -- no attachment point"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-016",
    kind: "K02",
    question:
      "A step must run the test suite and then read the file the failing test names, in the same step, and both are required. The catalogue holds G18 (G15, ['NC11']), NC16 (G15, ['NC08']) and G28 (G14, ['NC08','NC05']); the planner's rule is the smallest declared grant set that satisfies the postconditions. Which TYPE_A runs it?",
    options: ["G18 (G15, NC11)", "no class declares both", "G28 (G14, writes)"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-017",
    kind: "K02",
    question:
      "A step must label the refusal reason already recorded on the head state so the refusal-rate metric can count refusals by stage. All inputs are present in the state; the step reads and writes nothing. Which TYPE_A runs it?",
    options: ["G16 (propose only)", "G28 (G14, writes)"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-018",
    kind: "K02",
    question:
      "A G16 step has proposed a new capability: it needs to write the file it has just described. NC04 is false for G16. Which TYPE_A can a G16 step transition to in order to obtain a tool it lacks?",
    options: ["G28 (G14, writes)", "G16 (propose only)", "none -- no path exists"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-019",
    kind: "K02",
    question:
      "A step must read the workspace root listing. A class declares a POLICY_A whose scope narrows its tool grants to 'src/**', and the G26 matches a scope against the address exactly as given. Which TYPE_A runs the step?",
    options: ["G28 (G14, writes)", "G16 (propose only)", "none -- outside every grant's scope"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-020",
    kind: "K02",
    question:
      "A step must write the accepted summary to a file so the next state can pin it by content hash. Only one native class declares a write grant. Which TYPE_A runs it?",
    options: ["G16 (propose only)", "G28 (G14, writes)"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-021",
    kind: "K02",
    question:
      "A state carries a class ref whose declared name and version do not match the registered class at that content hash. Which TYPE_A runs the next step?",
    options: ["the class registered at that hash", "the class with the matching name", "none -- the ref is forged"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-022",
    kind: "K02",
    question:
      "The head state's budget envelope is NC09 1, semanticCalls 0, tools 0. The remaining work is one pure judgement over the projection with no tool use. Which TYPE_A runs the step?",
    options: ["G16 (propose only)", "G28 (G14, writes)", "none -- no call left"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-023",
    kind: "K02",
    question:
      "The head state's class is G16, and a transition is proposed that keeps the class and adds an NC05 grant to it. Which TYPE_A runs the next step?",
    options: ["G16 (propose only)", "G28 (G14, writes)", "G16 with an added grant"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-024",
    kind: "K02",
    question:
      "A step must fetch a page and summarise it. The catalogue holds G06 (G15, declared tools ['NC13']), G16 (NC18, no tools) and G28 (G14, ['NC08','NC05']); the planner's rule is the smallest declared grant set that satisfies the postconditions. Which TYPE_A runs it?",
    options: ["G06 (G15, NC13)", "G16 (propose only)", "G28 (G14, writes)"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-025",
    kind: "K02",
    question:
      "A step must compare two candidate patches that are both already carried in the state's resources by content hash, and emit the better one as a proposal summary. It must not touch the workspace. The catalogue holds G27 (NC18, POLICY_A 'none') and G28 (G14, ['NC08','NC05']); the planner's rule is the smallest declared grant set that satisfies the postconditions. Which TYPE_A runs it?",
    options: ["G27 (NC18, no tools)", "G28 (G14, writes)", "no class -- needs a read"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-026",
    kind: "K02",
    question:
      "The first of two steps must run the test suite so the engine can decide whether the second step's fix is needed. The class running the first step must observe the suite output before the decision is taken, and the deciding logic is the engine's. Which TYPE_A runs the first step?",
    options: ["G18 (G15, NC11)", "G28 (G14, writes)", "no class -- engine decides"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-027",
    kind: "K02",
    question:
      "A step must name which capability the next step will need, as part of its proposal payload, without requesting or receiving it. Which TYPE_A runs it?",
    options: ["G16 (propose only)", "G28 (G14, writes)", "no class -- engine grants"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-028",
    kind: "K02",
    question:
      "A layer has returned a proposal asserting that the test suite passed. Which TYPE_A runs the step whose outcome decides whether the commit is accepted?",
    options: ["G16 (propose only)", "G28 (G14, writes)", "none -- only a deterministic check"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-029",
    kind: "K02",
    question:
      "Two candidate states are byte-identical except that one carries a tool grant and the other does not. Which TYPE_A is responsible for the difference being real rather than an artefact of comparison?",
    options: ["G28 (G14, writes)", "no class -- not identity", "the granting class"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N01-030",
    kind: "K02",
    question:
      "A step must read workspace/package.json to find the typecheck command and then write a one-line change adding a script entry. Both the read and the write are required in this one step. The catalogue holds NC16 (G15, ['NC08']) and G28 (G14, ['NC08','NC05']); the planner's rule is the smallest declared grant set that satisfies the postconditions. Which TYPE_A runs it?",
    options: ["G28 (G14, writes)", "NC16 (G15, NC08)", "two steps, read then write"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  /* ==================================================================== */
  /* N10 -- which refs make up the compiled package for a step  */
  /* Invariants used: the projection is derived per step and never          */
  /* accumulated; the reflex stack selects the package before the model      */
  /* [withheld: section note naming internal mechanism — see the withheld rationale note, section 3] */
  /* compaction is non-destructive and preserves a fixed set.                 */
  /* ==================================================================== */

  {
    id: "N10-001",
    kind: "N10",
    question:
      "The current step's class has its own projection spec. The parent state carries a projection computed for the previous class. Which construction produces the context for this step?",
    options: ["recompute it from the state", "carry the parent body forward", "concatenate both projections", "relist every ancestor"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-002",
    kind: "N10",
    question:
      "The parent state's projection has a summary and a content-hashed body. This step's class names no part of that body. Structural sharing is automatic. Which parts of the parent projection may the compiler reuse?",
    options: ["the summary only", "the body, on matching hash", "both, unconditionally", "neither, ever"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-003",
    kind: "N10",
    question:
      "The package as compiled is 210,000 tokens and this step's explicit context budget is 80,000. The raw history is retained and re-queryable behind G21 and SEARCH. Which package does the step run with?",
    options: ["the full 210k package", "the compacted preserve set", "the newest 80k tokens", "nothing, and re-query later"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-004",
    kind: "N10",
    question:
      "A knowledge ref in the candidate set is pinned to version v1, and the knowledge module's current head for that claim is v2. Which of the two does the compiled package carry?",
    options: ["v2, the current head", "v1, the candidate", "both, side by side", "neither, cite the locator"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-005",
    kind: "N10",
    question:
      "The head state stores a tool grant with NC06 40, and the step being planned runs at epoch 41. Which capability families does the package carry for that grant?",
    options: ["the tool family, reissued", "model + context only", "the tool family, narrowed", "no families at all"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-006",
    kind: "N10",
    question:
      "Two consecutive steps use the same class, the same provider family and the same schema version, and the step's state fields are byte-identical to the previous step's. Which construction of the compiled package preserves the byte-identical prefix?",
    options: ["recompute the whole prompt", "the deterministic bootstrap manifest", "a model-written summary", "the last trace lines"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-007",
    kind: "N10",
    question:
      "Two candidate refs have the same scheme, locator prefix and content hash but different pins. The step's package budget has ample room. How many entries does the manifest carry?",
    options: ["one, deduplicated by hash", "two, one per pin", "two, plus a merge record", "none, the pins disagree"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-008",
    kind: "N10",
    question:
      "The step's manifest names a ref whose summary is a pointer to another ref, and this step's postcondition does not depend on the target. The step's context budget has room for a manifest entry but not for the target's body. Which does the package carry?",
    options: ["the target's full body", "the manifest entry only", "neither, the pointer is noise", "both, plus a summary line"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-009",
    kind: "N10",
    question:
      "The previous step's raw tool-result bodies total 400,000 tokens. This step's context budget is 80,000 and the step's postcondition names only the digests of those results. Which refs does the package carry?",
    options: ["the raw bodies, truncated", "the digests, by reference", "the newest 80k of bodies", "the full bodies, over budget"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-010",
    kind: "N10",
    question:
      "The head state is a refusal produced by the A2_provenance gate. The next step must decide whether to re-propose the same claim. Which does the compiled package carry?",
    options: ["the refusal state and its gate", "the refused proposal only", "nothing, refusals are noise", "the evidence, not the refusal"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-011",
    kind: "N10",
    question:
      "A third party who trusts neither the engine nor the live policy must be able to confirm the grant was legitimately produced. Which field must the package carry to make that possible?",
    options: ["the NC03 provenance", "the engine's signature", "the live policy document", "the class source file"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-012",
    kind: "N10",
    question:
      "The step's class is G16 (NC18, POLICY_A 'none'). The compiler's candidate list still contains a description of the NC05 tool, taken from the class documentation. What does the package do with it?",
    options: ["include it as context", "omit it entirely", "include it, redacted", "include it, read-only"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-013",
    kind: "N10",
    question:
      "The deterministic bootstrap manifest for this step is fixed. The reflex stack selects the package before the model sees it and is permitted to subtract from it, never to add. Which describes the resulting package?",
    options: ["the manifest, unmodified", "the manifest minus a subset", "the manifest plus a lead", "the model's chosen subset"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-014",
    kind: "N10",
    question:
      "The commit for this step must let a reader determine exactly which refs were paged into it, using only the commit and the raw history. Which record makes that possible?",
    options: ["the G08] ref list", "the token count alone", "the model's own account", "the manifest's mtime"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-015",
    kind: "N10",
    question:
      "A candidate ref's pin resolves to epoch 43, while the head state is at epoch 41. A write carrying an epoch above the head cannot be ordered against the lineage. What does the compiler do with the ref?",
    options: ["include it, newer is better", "exclude it, unorderable", "include it, pinned to head", "escalate the whole step"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-016",
    kind: "N10",
    question:
      "The state is rebuilt from its commit for a new step, and the task statement in the task namespace is unchanged. Which does the rebuilt package carry?",
    options: ["the task statement", "the task statement's digest only", "the previous step's prompt", "nothing, it is implicit"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-017",
    kind: "N10",
    question:
      "Compaction is applied to fit the context budget, and it must not lose anything a later gate will read. Which set does the compacted package preserve?",
    options: ["failures, decisions, unresolved, refs", "the most recent 20 turns", "the model's summary lines", "whatever fits the budget"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-018",
    kind: "N10",
    question:
      "A claim in the candidate set cites an evidence ref that the execution store has already superseded with a newer hash for the same measurement. Which does the package carry?",
    options: ["the newer evidence ref", "the cited, superseded ref", "both, as a conflict", "neither, drop the claim"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-019",
    kind: "N10",
    question:
      "The candidate set contains a resource ref whose content hash already appears in the head state's resources, with the same scheme and locator. How is it represented in the package?",
    options: ["one entry, shared by hash", "two entries, one per commit", "one entry, no locator", "dropped, already seen"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-020",
    kind: "N10",
    question:
      "The step must diff the current workspace against the last committed artifact. The postcondition names the digest, not the bytes. Which does the package carry?",
    options: ["the artifact ref, by hash", "the artifact body inline", "the workspace listing", "neither, diff it live"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-021",
    kind: "N10",
    question:
      "The parent class's projection payload holds a domain-specific field. This step's class projection spec does not name that field, and the field is not in the envelope. Which does the package carry?",
    options: ["keep it, it is in the state", "omit the field entirely", "include it as opaque text", "include it, redacted"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-022",
    kind: "N10",
    question:
      "The head state carries a projection with a summary and a content-hashed body, and this step is planned from that head. Which summary reaches the package?",
    options: ["the head's own summary", "the root state's summary", "a concatenation of all", "the model's paraphrase"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-023",
    kind: "N10",
    question:
      "The trace store holds 4,000 records of this run, including the model's raw completions. The commit semantics say trace events go to a separate store and never into the state. Which does the package carry?",
    options: ["no trace records at all", "the last 100 records", "the completion that was accepted", "records matching the digest"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-024",
    kind: "N10",
    question:
      "A candidate resource ref has scheme 'env' and its locator names a credential the sandbox must never hold. The state records the ref with a content hash. Which does the package carry?",
    options: ["the ref and its hash only", "the ref with the value", "the value, redacted", "nothing at all"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-025",
    kind: "N10",
    question:
      "The step must compare two candidate patches and emit the better one, and both are already pinned in the state's resources. Which does the package carry?",
    options: ["both refs, bodies by hash", "the larger patch only", "whichever the model prefers", "neither, the engine compares"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-026",
    kind: "N10",
    question:
      "Compaction is required to fit the budget, and one of the items in the preserve set is a refusal that the next step's gate decision reads directly. Which package does the step run with?",
    options: ["the compacted set, refusal dropped", "the compacted set, refusal kept", "the uncompacted package", "no package, defer the step"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-027",
    kind: "N10",
    question:
      "The head state has two parents. Which does the compiled package carry about its lineage?",
    options: ["both parent refs", "the first parent only", "the count alone", "neither, lineage is metadata"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N10-028",
    kind: "N10",
    question:
      "The projection body is content-hashed, and a projection that embeds the wall-clock time changes its hash on every run. plan() is pure: no clock, no randomness, no I/O. Which construction keeps replay deterministic?",
    options: ["embed the step's timestamp", "cache the first run's body", "derive it from state fields", "let the model write it"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  /* ==================================================================== */
  /* K05 -- which grant families the planner constructs.      */
  /* The kinds are model, tool, skill, resource and context. Every class    */
  /* [withheld: section note naming internal mechanism — see the withheld rationale note, section 3] */
  /* denylists never subtract, and a family is not trimmed per step.        */
  /* ==================================================================== */

  {
    id: "N09-001",
    kind: "K05",
    question:
      "The step's class is G16, whose POLICY_A is { kind: 'none' }. The grant kinds available are model, tool, skill, resource and context, and every class always receives a model grant and a context grant. Which family set does the planner construct?",
    options: ["model + context", "model + context + tool", "model + tool", "model + context + resource"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-002",
    kind: "K05",
    question:
      "The step's class is G28, whose POLICY_A is { kind: 'declared', tools: ['NC08','NC05'] }. Which family set does the planner construct?",
    options: ["model + context + tool", "model + context", "model + tool", "model + context + skill"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-003",
    kind: "K05",
    question:
      "The step's class is G16 (POLICY_A 'none'). Its returned proposal carries requestedCapabilities: [{ kind: 'tool', ref: 'NC05' }]. Which family set does the planner construct for this step?",
    options: ["model + context", "model + context + tool", "tool, replacing context", "model + context + tool, narrowed"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-004",
    kind: "K05",
    question:
      "A catalogued class declares POLICY_A { kind: 'declared', tools: ['NC08','NC05'] } and also declares two skills in its role spec. Which family set does the planner construct?",
    options: ["model + context + tool", "model + context + tool + skill", "model + context + skill", "model + context + tool + skill + resource"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-005",
    kind: "K05",
    question:
      "A catalogued class declares POLICY_A { kind: 'declared', tools: [] } and one resource grant pinning a read-only artefact by content hash. No skill is declared. Which family set does the planner construct?",
    options: ["model + context", "model + context + tool", "model + context + resource", "model + context + tool + resource"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-006",
    kind: "K05",
    question:
      "The step's class is G28 with declared tools ['NC08','NC05'], and the class's POLICY_A applies scope 'src/**' to every tool grant it declares. Which family set does the tool plane see?",
    options: ["model + context", "model + context + tool", "model + context + resource", "model + context + tool, unscoped"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-007",
    kind: "K05",
    question:
      "The state being resumed from stores a tool grant with NC06 40, and the step being planned runs at epoch 41. Which family set does the package for this step carry?",
    options: ["model + context + tool", "model + context", "model + context + tool, reissued", "model + context + resource"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-008",
    kind: "K05",
    question:
      "The same class is run once with an in-process G26 and once behind a hosted MCP server. The MCP server's tools/list is derived mechanically from the grants and is never curated. How do the two family sets relate?",
    options: ["identical, the transport differs", "hosted adds a transport family", "hosted drops the skill family", "native adds the model family"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-009",
    kind: "K05",
    question:
      "The tool plane is about to compile a NC07 for a network fetch. The step's class declares only ['NC08','NC05']. Which family set should reach the tool plane?",
    options: ["model + context + tool", "model + context", "model + context + tool + resource", "model + context + skill"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-010",
    kind: "K05",
    question:
      "The state's budget envelope has tools 0 remaining. The step's class is G28 with declared tools ['NC08','NC05']. Which family set does the planner construct?",
    options: ["model + context", "model + context + tool", "model + context + tool, empty", "model + tool"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-011",
    kind: "K05",
    question:
      "A change is proposed that adds one extra tool to the hosted MCP server's advertisement 'for convenience', with no corresponding grant. Which family set does the advertisement serve?",
    options: ["the same families as the grants", "grants plus the extra tool", "the extra tool only", "no tools at all"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-012",
    kind: "K05",
    question:
      "A worker requests a model by name that differs from the one its class declared. Which grant family's absence makes that request unsatisfiable?",
    options: ["model", "context", "tool", "resource"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-013",
    kind: "K05",
    question:
      "The compiled prompt contract is keyed by class, provider family and schema version, and the context grant's ref is the string 'name@version'. Which family carries the class identity into the contract?",
    options: ["model", "context", "tool", "skill"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-014",
    kind: "K05",
    question:
      "A proposal requesting a new capability has been admitted, and the resulting state has a different class. The current step's families were model + context. What is the next step's family set?",
    options: ["the current step's families", "the new class's declared families", "the union of both sets", "model + context + tool"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-015",
    kind: "K05",
    question:
      "A change is proposed that gives a class a denylist field, so certain tools can be listed as forbidden. Which family set results?",
    options: ["a new denial family", "the permitted families only", "an empty family set", "model + context + tool"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-016",
    kind: "K05",
    question:
      "A class's role description reads 'applies changes with NC05', but its POLICY_A is { kind: 'none' } and its layer is NC18. Which family set does the planner construct?",
    options: ["model + context + tool", "model + context", "model + tool", "model + context + skill"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-017",
    kind: "K05",
    question:
      "The step's class is G28 with declared tools ['NC08','NC05'], and this particular step's postconditions require only a read. The planner has already selected the class. May it drop the NC05 family from the materialised set for this step alone?",
    options: ["yes, per-step families", "no, families emit in full", "yes, and narrow the read", "no, and split the step"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-018",
    kind: "K05",
    question:
      "The compiled prompt contract is content-addressed per (class, provider family, schema version). Which family does the schema version belong to, given that the context grant's ref is 'name@version' and no other grant carries a schema field?",
    options: ["model", "context", "tool", "resource"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-019",
    kind: "K05",
    question:
      "The tool plane is implemented by Needle 3, a grammar-constrained generator that compiles ActionIR into a schema-valid NC10 Which family is it given, and why is that not a modelling preference?",
    options: ["tool, grammar-constrained", "skill, it is a named capability", "resource, it resolves a ref", "model, it picks the model"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-020",
    kind: "K05",
    question:
      "A worker asks the G26 for a model the transition did not materialise. The worker's own config names that model and the class's NC14 names a different one. Which family's absence is the reason the request fails?",
    options: ["model", "context", "tool", "resource"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-021",
    kind: "K05",
    question:
      "The step's class is G28 with declared tools ['NC08','NC05'], and the budget envelope has tools 1 remaining. Which family set does the planner construct?",
    options: ["model + context", "model + context + tool", "tool, one entry only", "model + tool"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-022",
    kind: "K05",
    question:
      "MATERIALISE_A() sorts the constructed grants by the string 'kind:ref:scope' — an absent scope being the empty final segment — so the policy hash is stable. Given kinds context, model and tool, which family appears first in the emitted array?",
    options: ["context", "model", "tool", "the family with the most grants"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-023",
    kind: "K05",
    question:
      "A hosted MCP server is proposed for an NC18 class whose POLICY_A is 'none'. What does its tools/list contain?",
    options: ["model + context", "nothing at all", "model + tool", "the class's described tools"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-024",
    kind: "K05",
    question:
      "One class is run with an in-process G26 and another with a hosted MCP server, and both declare the same POLICY_A. Does the second run's family set differ from the first's?",
    options: ["yes, hosted is broader", "no, they are identical", "yes, native is broader", "only if a skill is declared"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-025",
    kind: "K05",
    question:
      "What makes a grant not outlive the state that issued it? The envelope defines NC06 on CapabilityGrant and no other field carries the issuing epoch.",
    options: ["the model family", "the tool family", "every family", "no family carries it"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N09-026",
    kind: "K05",
    question:
      "Two states are byte-identical except that one carries a tool grant and the other does not, and their content hashes differ. Which family's presence accounts for the difference?",
    options: ["the tool family", "the model family", "the context family", "no family; only fields matter"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  /* ==================================================================== */
  /* K07 -- which tier a candidate takes in the memory module. */
  /* G07: this step only. G10: this task run. G03: a     */
  /* repeatable method that generalises. G02: a durable fact that is */
  /* not a method. G31: it is not memory -- the knowledge, execution and    */
  /* meta stores own it, or it is duplicate, superseded, or already a state.*/
  /* ==================================================================== */

  {
    id: "N08-001",
    kind: "K07",
    question:
      "A candidate record holds a scratch list of file paths the running step considered. No later step in this task will read it and the step finishes in one call. Which tier does the memory module admit it at?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-002",
    kind: "K07",
    question:
      "A candidate record lists the classes visited so far during this task run. It is needed for the remaining steps of this run and for nothing in any later run. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-003",
    kind: "K07",
    question:
      "A candidate record is the command that regenerates the client in this repository, together with the flag that keeps the output stable. It is a method, and it applies to any future task against this repository. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 3,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-004",
    kind: "K07",
    question:
      "A candidate record states that this repository pins its package manager in package.json. It is a fact about the project, not a method, and it will still be true next year. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 4,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-005",
    kind: "K07",
    question:
      "A candidate record restates a claim the knowledge module already holds: that the gateway returns 200 on an empty body. The claim, its source and its confidence are all identical to the stored version. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-006",
    kind: "K07",
    question:
      "A candidate record is the refusal produced by the A3_budget gate on the previous step, together with its reason and its gate. The head state already carries it. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-007",
    kind: "K07",
    question:
      "A candidate record is a route-and-outcome table: task class X routed to path Y, 78 % success over 40 samples. The meta module owns route-and-outcome records. Which tier does the memory module admit it at?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-008",
    kind: "K07",
    question:
      "A candidate record notes that the G18's digest check for generated clients is unreliable, learned across three separate tasks in three separate runs. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 3,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-009",
    kind: "K07",
    question:
      "A candidate record lists the class names this step considered and rejected. It is discarded the moment the plan is made and no later step will read it. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-010",
    kind: "K07",
    question:
      "A candidate record has the same content hash as a G03 record already admitted to the memory module. The records differ in nothing but their pin. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-011",
    kind: "K07",
    question:
      "A candidate record's only support is an evidence ref that the execution store has already superseded with a newer hash for the same measurement. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-012",
    kind: "K07",
    question:
      "A candidate record holds the absolute path of the workspace root for this task. The remaining steps of this run need it; no later run will, because every run gets a fresh workspace. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-013",
    kind: "K07",
    question:
      "A candidate record states that the user prefers metric units in every answer. It is a fact about a standing preference, not a method, and it holds for every future task. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 4,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-014",
    kind: "K07",
    question:
      "A candidate record is the command that runs only the gate-delegation suite, discovered by reading package.json. It is a method for reproducing one specific check. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 3,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-015",
    kind: "K07",
    question:
      "A candidate record holds the filesystem path of the G26 socket this step is using. The socket is created at materialisation and removed when the step's epoch ends. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-016",
    kind: "K07",
    question:
      "A candidate record restates a knowledge claim whose current version in the knowledge module is a different claim about the same subject. The knowledge module merges by supersede. Which tier does the memory module admit it at?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-017",
    kind: "K07",
    question:
      "A candidate record states that the upstream registry stopped publishing 32-bit images in March and will not resume. It is a fact about the world, not a method, and it outlives this project. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 4,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-018",
    kind: "K07",
    question:
      "A candidate record is the verbatim text a model returned on the previous step. It makes no claim, states no method, and its value is that it is what was returned. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-019",
    kind: "K07",
    question:
      "A candidate record is a cached copy of the compiled prompt package, kept so the next call can reuse a byte-identical prefix. It is derived from one step's state and is rebuilt per step. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-020",
    kind: "K07",
    question:
      "A candidate record duplicates, field for field, something the head state's resources already pin by content hash. It adds no provenance the state does not already hold. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-021",
    kind: "K07",
    question:
      "A candidate record holds the exact bwrap flag list used to materialise one step. The next step derives its own spec from the class and the epoch, so these flags are not reusable. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-022",
    kind: "K07",
    question:
      "A candidate record is a refusal reason the user asked about in this session. The identical refusal is already committed as a state carrying gate A2_provenance. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-023",
    kind: "K07",
    question:
      "A candidate record names the two tests that failed during this run, with their exit codes. The rest of this run will consult them; the next run will have its own failures. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-024",
    kind: "K07",
    question:
      "A candidate record states a general rule this run confirmed: a class may refine the envelope's payload but may never extend it, so a new envelope field is a schema version bump. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 3,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-025",
    kind: "K07",
    question:
      "A candidate record is the exact sequence that reproduces a failed step deterministically, worked out across three separate failures in three separate runs. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 3,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-026",
    kind: "K07",
    question:
      "A candidate record states a fact the user gave about an external billing system: invoices are issued monthly on the first. It is a fact, not a method, and it is still true next year. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 4,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-027",
    kind: "K07",
    question:
      "A candidate record is a scratch buffer of results from a search this step ran, together with the query. The step has already used the results and will not repeat the search. Which tier?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N08-028",
    kind: "K07",
    question:
      "A candidate record is an outcome record for one step: the command that ran, and exit code 1. The proposal that carries it is already committed on the state. Which tier does the memory module admit it at?",
    options: ["G31", "G07", "G10", "G03", "G02"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  /* ==================================================================== */
  /* K01 -- G20 or G11.                                     */
  /* 22 of these 30 have G11 as the label, on purpose: abstention is   */
  /* the property most likely to be claimed and least likely to be tested,  */
  /* and a set that only rewards an answer measures the wrong thing.         */
  /* ==================================================================== */

  {
    id: "N07-001",
    kind: "K01",
    question:
      "Verification of this step's postcondition has already failed twice, both times on the same deterministic check, both times under this same class. A third attempt under the same class would run the same check against the same expectation. Should this step answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-002",
    kind: "K01",
    question:
      "The question requires a judgement the state does not record, and the budget envelope has NC09 0 remaining. A class that could produce that judgement would need a model call. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-003",
    kind: "K01",
    question:
      "The state this step would read is at epoch 39, while the lineage head is at epoch 41. Any proposal built from it carries a stale epoch and is refused by the A5_epoch gate. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-004",
    kind: "K01",
    question:
      "The only evidence supporting the claim is a ref that the evidence store has already superseded with a newer hash for the same measurement. The claim cannot be re-grounded from anything else in the state. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-005",
    kind: "K01",
    question:
      "The question is 'which of the two candidate states was written first', and nothing in the state records the two timestamps. The step's grants name no SEARCH tool and no clock is available, since plan() takes environment facts from the state and never from the process. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-006",
    kind: "K01",
    question:
      "The question asks about a repository that appears nowhere in the task namespace, the evidence namespace or the execution namespace of this state. Nothing in the state is about it. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-007",
    kind: "K01",
    question:
      "The question can only be answered by reading a file, and the step's class is G16, whose POLICY_A is 'none' and whose NC02 is false. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-008",
    kind: "K01",
    question:
      "Two evidence refs in the state make the same measurement with opposite results, and neither ref's pin is later than the other's. The store's merge for evidence is an OR-Set, which unions rather than resolves. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-009",
    kind: "K01",
    question:
      "The proposal this step would return does not conform to its class's payload schema, and the A1_schema gate would refuse it. Nothing in the state says what the correct payload shape is for this class version. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-010",
    kind: "K01",
    question:
      "The declared spend for this transition is tools 6 against a remaining envelope of tools 2, and the tool calls cannot be made smaller without failing the postcondition. The A3_budget gate would refuse the proposal. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-011",
    kind: "K01",
    question:
      "The question is 'which version of the G28 class is better'. The state references G28@1.0.0 by hash and holds no criteria, no comparison and no record of any other version's use. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-012",
    kind: "K01",
    question:
      "The answer depends on a tool-result ref whose content hash does not resolve in any store the state names, and the proposal's only provenance pointer is to that ref. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-013",
    kind: "K01",
    question:
      "The request is 'give the G16 class an NC05 grant so it can finish this task'. A role may propose capability and may never grant it to itself. Answer or escalate?",
    options: ["G20", "G11", "G29 THE G30 IN PLACE"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-014",
    kind: "K01",
    question:
      "A NC01 is on the table whose proposer identity is the same identity that would be recorded as its evaluator. The rule is that a proposal's proposer and its evaluators must be disjoint identity refs. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-015",
    kind: "K01",
    question:
      "The answer requires a capability that appears in no grant on this state, and the class is G14, so an G05 path does exist. The state does not record which class would hold that capability. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-016",
    kind: "K01",
    question:
      "Two branches of the lineage disagree about the order of two planned steps, and the merge algebra for ordered plans is a sequence CRDT plus an explicit typed conflict record. The state records both orders and no tie-break. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-017",
    kind: "K01",
    question:
      "The answer is in a resource whose scheme is 'memory', and the step's grants name no memory resource, so the ref cannot be paged into this package. Nothing else in the state contains the same fact. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-018",
    kind: "K01",
    question:
      "The question asks which grant set is currently effective, and the head state's stored capabilities disagree with what its NC03 re-derives. Either the stored grant or the policy is wrong, and the state does not say which. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-019",
    kind: "K01",
    question:
      "The only thing asserting that the postcondition holds is a layer's own claim, recorded in verification[] and marked unverified. No deterministic check exists for this postcondition. Answer or escalate?",
    options: ["G20", "G11", "G31 THE CLAIM AND G09"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-020",
    kind: "K01",
    question:
      "The state presented to this step was authored by a layer rather than minted by the engine, and it carries a proposal and a verdict the engine never produced. Answer or escalate?",
    options: ["G20", "G11", "G22 THE G32 AND G09"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-021",
    kind: "K01",
    question:
      "The head state's class ref does not resolve in the catalogue: the name and version recorded on the ref disagree with the registered class at that content hash. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-022",
    kind: "K01",
    question:
      "The step's context budget cannot be met: compaction has already been applied once, and the artifact refs alone exceed what remains. The question cannot be answered from what fits. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-023",
    kind: "K01",
    question:
      "The question is 'what is this state's task statement', and the state carries the task in the task namespace with its exact recorded text. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-024",
    kind: "K01",
    question:
      "The question is 'which gate refused the last proposal', and the head state is a refusal carrying both its reason and the gate that produced it. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-025",
    kind: "K01",
    question:
      "The question is 'what tools does this step hold', and the class's POLICY_A and the step's epoch are both recorded on the state, so the set is exactly re-derivable by construction. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-026",
    kind: "K01",
    question:
      "The question is 'how many parents does the head commit have', and the parents array is on the state and included in the body digest. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-027",
    kind: "K01",
    question:
      "The question is 'is NC05 permitted for this step', and this step's capabilities contain a model grant, a context grant and no tool grant. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-028",
    kind: "K01",
    question:
      "The question is 'which capability families does this step hold', and the class is G16 with POLICY_A 'none' at a recorded epoch, so the constructed set is fully determined. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-029",
    kind: "K01",
    question:
      "The question is 'is this commit a merge', and the head state's parents array has exactly one entry. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N07-030",
    kind: "K01",
    question:
      "The question is 'which class runs the next step', the step's postconditions require an on-disk write, and exactly one catalogued class declares a write grant. Answer or escalate?",
    options: ["G20", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  /* ==================================================================== */
  /* K04 -- G24(x) | G12(x,y) | G13(x,y) | G23.        */
  /* One class per step and the Reducer alone mints a merge commit, so a    */
  /* step's shape follows from what consumes what, not from what is cheap.   */
  /* ==================================================================== */

  {
    id: "N02-001",
    kind: "K04",
    question:
      "Two candidates are on the table: (A) read workspace/MODULE_4, (B) write the fix to that file. B's content is determined by what A returns, and both are admissible. Which G17 runs this step?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-002",
    kind: "K04",
    question:
      "Two candidates: (A) read workspace/tsconfig.json, (B) read workspace/package.json. Neither reads what the other produces, both are pure reads, and the step compares them afterwards. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-003",
    kind: "K04",
    question:
      "Two candidates: (A) run the test suite, (B) write the fix. The fix's content is the correction the suite's failure output names, so B cannot be written before A has run. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-004",
    kind: "K04",
    question:
      "Two candidates: (A) write to /etc/hosts, (B) run a shell command through a tool that appears in no grant on this state. Neither is reachable, and both were proposed by the same layer that proposed them. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 3,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-005",
    kind: "K04",
    question:
      "Two candidates: (A) write workspace/src/a.ts, (B) write workspace/src/b.ts. B's content is computed from the exported symbol list A produces. Both are admissible and neither path is read by the other. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-006",
    kind: "K04",
    question:
      "Two candidates: (A) fetch a URL through a web tool that this state's grants do not name, (B) read the local fixture that already contains the same payload. Only B is admissible. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-007",
    kind: "K04",
    question:
      "Two candidates, both of which require one tool call, and the budget envelope has tools 0 remaining. The postconditions cannot be met by any other means. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 3,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-008",
    kind: "K04",
    question:
      "Two candidates: (A) verify the artefact digest, (B) run the test suite. A deterministic check already recorded on the head state has satisfied both, with their results, and re-running either would produce a state byte-identical to the head. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 3,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-009",
    kind: "K04",
    question:
      "Two candidates: (A) verify the content hash of the pinned artefact, (B) run the test suite. Both are pure, neither consumes the other, and the step's postcondition requires both to be recorded. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-010",
    kind: "K04",
    question:
      "Two candidates: (A) propose a transition to a class that declares NC05, (B) perform the write under that new class. Both are described in the same plan, and the engine admits (A) before (B) may run. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-011",
    kind: "K04",
    question:
      "Two candidates: (A) read the knowledge claim pinned at hash k1, (B) read the knowledge claim pinned at hash k1 under a different locator. Both resolve to the same content hash, and the step's package is at its cap. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-012",
    kind: "K04",
    question:
      "Two candidates: (A) read the head state's projection, (B) read the pinned evidence ref the proposal will cite. Both are pure reads of already-materialised content, and neither depends on the other. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-013",
    kind: "K04",
    question:
      "Two candidates: (A) G21 a manifest ref and read its body, (B) cite that ref in the proposal. The proposal's provenance must resolve to content the step has actually seen, and the budget has room for the body. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-014",
    kind: "K04",
    question:
      "Two candidates: (A) read a file from the workspace, (B) run the test suite. The step's class is G16, whose POLICY_A is 'none', so it holds no tool grants. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 3,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-015",
    kind: "K04",
    question:
      "One candidate is on the table: (A) emit the proposal naming the class that should follow. The planner recorded no second candidate, the package for (A) is fully compiled, and its postcondition is satisfiable. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-016",
    kind: "K04",
    question:
      "Two candidates: (A) write workspace/docs/RESULTS.md, (B) pin that file's content hash into the next state so it can be verified later. B's value is the digest of what A wrote. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-017",
    kind: "K04",
    question:
      "Two candidates: (A) read the parent state, (B) read the grandparent state. The step must produce the semantic diff across the last two transitions, and neither read depends on the other. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-018",
    kind: "K04",
    question:
      "Two candidates: (A) write workspace/src/x.ts, (B) write workspace/src/y.ts. The paths are disjoint, neither consumes the other, and both writes are required. The class is G14, so both grants materialise. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-019",
    kind: "K04",
    question:
      "Two candidates, (A) and (B), are both admissible pure reads, but this step's compiled package is already at its context cap and the postcondition names only (A)'s content. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-020",
    kind: "K04",
    question:
      "Two candidates: (A) read a ref pinned at epoch 43, (B) read a ref pinned at epoch 44. The head state is at epoch 41, and a ref above the head cannot be ordered against this lineage. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 3,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-021",
    kind: "K04",
    question:
      "Two candidates: (A) run the typecheck, (B) apply the type fix. B's content is the correction named by A's exit output, and neither can start before the other has finished. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N02-022",
    kind: "K04",
    question:
      "Two candidates: (A) read docs/POLICY.md, (B) read MODULE_5. The step's output is a report of where the document and the code disagree, and neither read depends on the other. Which G17?",
    options: ["G24(A)", "G12(A,B)", "G13(A,B)", "G23"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  /* ==================================================================== */
  /* K03 -- what the context compiler does with a candidate ref.    */
  /* The stack selects the package before the model sees it and may only    */
  /* [withheld: section note naming internal mechanism — see the withheld rationale note, section 3] */
  /* whose algebra declares one is surfaced, never silently resolved.       */
  /* ==================================================================== */

  {
    id: "N06-001",
    kind: "K03",
    question:
      "A candidate tool-result ref is cited by the proposal the current step is about to make, and A2_provenance requires a cited source to resolve. The claim's verdict does not depend on the ref's body, and this step's context budget has ample room for a manifest entry. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-002",
    kind: "K03",
    question:
      "A candidate evidence ref records a measurement that the evidence store has already superseded with a newer hash. No proposal cites it and no postcondition names it. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-003",
    kind: "K03",
    question:
      "A candidate ref has the same scheme, locator and content hash as an entry already in this step's manifest, differing only in its pin string. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-004",
    kind: "K03",
    question:
      "A manifest ref's summary mentions a configuration detail this step's postcondition turns on, and the summary does not state what the detail is. The step holds a SEARCH grant bounded to the ref's namespace, and the ref's body fits the step's remaining context budget. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-005",
    kind: "K03",
    question:
      "A candidate knowledge claim contradicts the current head of the knowledge store for the same subject, and its pin is not demonstrably later than the head's. The knowledge store's merge is supersede. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 3,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-006",
    kind: "K03",
    question:
      "A candidate ref is a NC01 object. The state carries no evaluation record for it, and the identity that would evaluate it is the same identity that proposed it. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 4,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-007",
    kind: "K03",
    question:
      "A candidate ref's pin resolves to epoch 43 while the head state is at epoch 41, and nothing in the state records how that ref relates to this lineage. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 4,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-008",
    kind: "K03",
    question:
      "A candidate artefact ref is the one the next step's postcondition names, and this step's postcondition does not. The body is far larger than this step's remaining context budget. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-009",
    kind: "K03",
    question:
      "A candidate ref's scheme is 'memory', the step's grants name no memory resource, and no postcondition and no proposal cites it. The step holds no SEARCH grant. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-010",
    kind: "K03",
    question:
      "Two candidate evidence refs make the same claim with different sources and different confidences, and the proposal cites both. The evidence namespace's merge is an OR-Set, which unions. What does the compiler do with them?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-011",
    kind: "K03",
    question:
      "A manifest ref is itself a pointer to a third ref, and this step's postcondition requires the third ref's content. The step's grant covers the target namespace and the target body fits the remaining budget. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-012",
    kind: "K03",
    question:
      "A candidate ref offers a raw body that is already present, in full, inside the package this step has compiled. The manifest records it separately. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-013",
    kind: "K03",
    question:
      "This step's postcondition cannot be satisfied without a ref's contents, and no class in this lineage declares the capability needed to read it. The state does not record which class would. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 4,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-014",
    kind: "K03",
    question:
      "A candidate knowledge ref is small, already cited by the proposal, in scope for this step's knowledge grant, and its body is 400 tokens against a step with 20,000 tokens of headroom. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-015",
    kind: "K03",
    question:
      "A candidate ref is an G07 memory record written at epoch 40, and this step runs at epoch 41. Nothing in the step's postconditions or proposal names it. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-016",
    kind: "K03",
    question:
      "A candidate ref is currently carried as a manifest entry only, and this step's postcondition turns on a figure that appears in its body and nowhere in the summary. The step holds the grant and has 9,000 tokens of headroom against a 6,000-token body. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 2,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-017",
    kind: "K03",
    question:
      "A candidate knowledge claim carries a higher pin than the current head for its subject, so it looks newer, and the knowledge store's merge is supersede rather than compare. No verification record exists for either version. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 3,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-018",
    kind: "K03",
    question:
      "Two candidate tool-result refs record the same command with exit code 0 and exit code 1 respectively, and neither ref's pin is later than the other's. The execution namespace records a typed conflict for exactly this case. What does the compiler do with them?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 3,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-019",
    kind: "K03",
    question:
      "A candidate ref's locator resolves to a path that matches no scheme the state declares -- it is not artifact, memory, knowledge, tool-result or env. Its hash is well-formed. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 4,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-020",
    kind: "K03",
    question:
      "A candidate ref came from a portion of the previous package that compaction removed. This step's budget has no room for its body, nothing cites it, and no postcondition names it. The raw history is still retrievable behind G21. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-021",
    kind: "K03",
    question:
      "A candidate ref is a tool-result whose verification record says the result was a model assertion rather than a deterministic check. It is the only source offered for the claim the current step wants to make. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 4,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-022",
    kind: "K03",
    question:
      "A manifest ref's summary names a lead that this step would like to follow, but the step's knowledge grant is scoped to a different subject and does not cover the ref's subject. The ref itself is in scope and the manifest has room. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-023",
    kind: "K03",
    question:
      "Two candidate refs both claim to be the current head of the same knowledge claim, and the store's head pointer for that subject is absent from the state. The two refs have different pins. What does the compiler do with them?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 4,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-024",
    kind: "K03",
    question:
      "A candidate ref has scheme 'tool-result', its content hash resolves in no store the state names, and no proposal cites it and no postcondition names it. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 0,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-025",
    kind: "K03",
    question:
      "A knowledge claim in the store states that the sandbox mounts /home read-only, and a new candidate ref states it mounts read-write. Both are current claims in the knowledge module and neither has a recorded evaluation. What does the compiler do with the new ref?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 3,
    rationale:
      "",
    namespaces: [],
  },
  {
    id: "N06-026",
    kind: "K03",
    question:
      "A candidate ref is the only record that a prior step's NC05 actually happened, and the current step must be able to say what changed without holding any tool. The ref's body is already paged into this step's package. What does the compiler do with it?",
    options: ["G19", "G04", "G21", "G01", "G11"],
    correct: 1,
    rationale:
      "",
    namespaces: [],
  },
];

