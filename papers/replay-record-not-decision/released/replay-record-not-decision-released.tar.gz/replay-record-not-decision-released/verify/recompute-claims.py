#!/usr/bin/env python3
"""verify/recompute-claims.py -- paper #2 "Replay reproduces the record, not the decision".

ONE PURPOSE: re-derive EVERY headline number in the paper's manuscript (not distributed)
from the bytes that ship inside this package, using the Python standard library only.

Reads (only these, all relative to this tree):
    data/decision-variants.jsonl    3,040 rows = 4 models x 190 cases x 4 variants
    data/l1-head-to-head.jsonl        380 rows = 2 models x 190 cases
    (the stimulus fixture is NOT in this package: it releases with the companion
     note on Zenodo, concept DOI 10.5281/zenodo.23463944 -- see README.md and
     MANUSCRIPT.md section 7)

Definitions are the manuscript's, verbatim (MANUSCRIPT.md:125-131):
    decision divergence  = `picked_index` differs between the two rows
    outcome divergence   = (`picked_index == correct`) differs between the two rows
    binding divergence   = one model pair at one variant, over the 190 cases
    prompt divergence    = one model, V0 vs V1
    control              = V0<->V2 and V1<->V3 on NON-DECOMPOSABLE cases only

`correct` IS AN OPTION INDEX, NOT A BOOLEAN (MANUSCRIPT.md:90-106).  Every check below derives
outcome as `picked_index == correct`; a checker that summed `correct` as a flag would print a
meaningless accuracy, which is checked-for explicitly.

EXIT STATUS IS THE RESULT.  Every comparison in this file is folded into the exit code: the script
exits 0 only when every published value is reproduced, and 1 otherwise.  Printing
"reproduced=False" while exiting 0 is the exact failure this checker exists to prevent.

Usage: python3 verify/recompute-claims.py      (run from anywhere; reads only this tree)
"""
from __future__ import annotations

import hashlib
import itertools
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

# --- published values, cited to the manuscript ------------------------------------------------
PUB = {
    "binding_V0_n": 476, "binding_V0_d": 1140, "binding_V0_rate": 41.7544,
    "binding_V1_n": 537, "binding_V1_rate": 47.1053,
    "binding_V2_n": 456, "binding_V2_rate": 40.0000,
    "binding_V3_n": 494, "binding_V3_rate": 43.3333,
    "spread_lo": 40.00, "spread_hi": 47.11,
    "outcome_V0_n": 324, "outcome_V0_rate": 28.4211,
    "outcome_V1_n": 371, "outcome_V2_n": 358, "outcome_V3_n": 383,
    "control_n": 244, "control_identical": 244,
    "prompt_n": 245, "prompt_d": 760, "prompt_rate": 32.2368,
    "l1_n": 98, "l1_d": 190, "l1_rate": 51.5789,
}
# digests of the shipped bytes, and of the sources they were copied from (identical by construction)
DIGESTS = {
    "data/decision-variants.jsonl":
        "c5ec44a799ddeb963f862fc5c054ddad6ef2fce6ad90edfafd7c1755ac4370e7",
    "data/l1-head-to-head.jsonl":
        "6af0e0d8294cf4d7a20e2d8cb9bfe0c11ff70cc4c4b2792fcdedaf9246b2a1e7",
}
TOL = 5e-4
CHECKS = []


def check(name, ok, detail):
    CHECKS.append((name, bool(ok)))
    print("  [%s] %-34s %s" % ("PASS" if ok else "FAIL", name, detail))
    return bool(ok)


def jload(*p):
    with open(os.path.join(ROOT, *p), encoding="utf-8") as fh:
        return json.load(fh)


def jlines(*p):
    rows = []
    with open(os.path.join(ROOT, *p), encoding="utf-8") as fh:
        for ln in fh:
            if ln.strip():
                rows.append(json.loads(ln))
    return rows


def sha256(p):
    h = hashlib.sha256()
    with open(os.path.join(ROOT, p), "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def rate(n, d):
    return 100.0 * n / d


def main() -> int:
    print("verify/recompute-claims.py -- paper #2 replay-record-not-decision")
    print("tree: %s\n" % ROOT)

    # ---- 0. the shipped bytes are the bytes the manuscript was written from -------------------
    print("SHIPPED BYTES (digest pinned by README.md)")
    for rel, want in DIGESTS.items():
        if not os.path.isfile(os.path.join(ROOT, rel)):
            check("digest:%s" % rel, False, "MISSING")
            continue
        got = sha256(rel)
        check("digest:%s" % rel, got == want, "sha256=%s" % got[:16])

    # ---- 1. shape ------------------------------------------------------------------------------
    print("\nSHAPE")
    dv = jlines("data", "decision-variants.jsonl")
    l1 = jlines("data", "l1-head-to-head.jsonl")
    models = sorted({r["model"] for r in dv})
    variants = sorted({r["variant"] for r in dv})
    cases = sorted({r["id"] for r in dv})
    check("dv rows == 3040", len(dv) == 3040, "rows=%d" % len(dv))
    check("l1 rows == 380", len(l1) == 380, "rows=%d" % len(l1))
    check("4 models", len(models) == 4, "%s" % models)
    check("4 variants", len(variants) == 4, "%s" % variants)
    check("190 distinct cases", len(cases) == 190, "cases=%d" % len(cases))
    check("dv is complete grid 4x190x4", len(dv) == len(models) * len(cases) * len(variants),
          "%d = %d x %d x %d" % (len(dv), len(models), len(cases), len(variants)))
    check("no errored rows", all(r.get("error") is None for r in dv) and
          all(r.get("error") is None for r in l1),
          "dv error!=None %d, l1 error!=None %d"
          % (sum(1 for r in dv if r.get("error") is not None),
             sum(1 for r in l1 if r.get("error") is not None)))
    idx = {(r["model"], r["variant"], r["id"]): r for r in dv}
    li = {(r["model"], r["id"]): r for r in l1}

    # ---- 2. the `correct`-column trap ----------------------------------------------------------
    print("\nTHE `correct` TRAP (MANUSCRIPT.md:90-106): `correct` is an option index, not a flag")
    cvals = sorted({r["correct"] for r in dv})
    lvals = sorted({r["correct"] for r in l1})
    pvals = sorted({r["picked_index"] for r in dv})
    check("`correct` is int, never bool",
          all(isinstance(r["correct"], int) and not isinstance(r["correct"], bool)
              for r in dv + l1), "types ok over %d rows" % (len(dv) + len(l1)))
    check("`correct` values are indices 0..4", cvals == [0, 1, 2, 3, 4], "dv=%s l1=%s" % (cvals, lvals))
    check("`correct` is NOT a 0/1 flag", any(v > 1 for v in cvals),
          "values >1 present: %s" % [v for v in cvals if v > 1])
    check("`picked_index` is -1..4 (-1 = no pick)", pvals == [-1, 0, 1, 2, 3, 4], "%s" % pvals)
    check("line-1 trap: l1 correct=0 but picked=1 (a WRONG answer whose flag is 0)",
          l1[0]["correct"] == 0 and l1[0]["picked_index"] == 1,
          "l1[0] correct=%r picked_index=%r" % (l1[0]["correct"], l1[0]["picked_index"]))
    check("line-1 dv correct=1 picked=1", dv[0]["correct"] == 1 and dv[0]["picked_index"] == 1,
          "dv[0] correct=%r picked_index=%r" % (dv[0]["correct"], dv[0]["picked_index"]))
    # the outcome axis is DERIVED -- demonstrate the flag-reading error it prevents
    wrong_acc = sum(r["correct"] for r in l1) / len(l1)
    right_acc = sum(r["picked_index"] == r["correct"] for r in l1) / len(l1)
    check("flag-reading `sum(correct)` is meaningless (hence the derived axis)",
          abs(wrong_acc - right_acc) > 0.4,
          "sum(correct)/n=%.4f vs (picked==correct)/n=%.4f" % (wrong_acc, right_acc))

    # ---- 3. binding divergence, per variant ---------------------------------------------------
    print("\nBINDING DIVERGENCE (decision = picked_index differs; n = 6 pairs x 190 cases = 1140)")
    bind = {}
    for v in variants:
        n = d = o = 0
        for m1, m2 in itertools.combinations(models, 2):
            for c in cases:
                a, b = idx[(m1, v, c)], idx[(m2, v, c)]
                n += 1
                d += a["picked_index"] != b["picked_index"]
                o += ((a["picked_index"] == a["correct"]) != (b["picked_index"] == b["correct"]))
        bind[v] = (d, n, o)
    for v, key in (("V0", "binding_V0"), ("V1", "binding_V1"),
                   ("V2", "binding_V2"), ("V3", "binding_V3")):
        d, n, o = bind[v]
        want_n, want_rate = PUB[key + "_n"], PUB[key + "_rate"]
        check("%s binding == %d/1140 (%.4f%%)" % (v, want_n, want_rate),
              (d, n) == (want_n, 1140) and abs(rate(d, n) - want_rate) <= TOL,
              "measured %d/%d = %.4f%%" % (d, n, rate(d, n)))
    check("outcome divergence V0 == %d/1140 (%.4f%%)" % (PUB["outcome_V0_n"], PUB["outcome_V0_rate"]),
          bind["V0"][2] == PUB["outcome_V0_n"] and
          abs(rate(bind["V0"][2], bind["V0"][1]) - PUB["outcome_V0_rate"]) <= TOL,
          "measured %d/%d = %.4f%%" % (bind["V0"][2], bind["V0"][1], rate(bind["V0"][2], bind["V0"][1])))
    for v, k in (("V1", "outcome_V1_n"), ("V2", "outcome_V2_n"), ("V3", "outcome_V3_n")):
        check("%s outcome == %d" % (v, PUB[k]), bind[v][2] == PUB[k], "measured %d" % bind[v][2])
    rates = [rate(bind[v][0], bind[v][1]) for v in variants]
    lo, hi = round(min(rates), 2), round(max(rates), 2)
    check("per-variant spread 40.00-47.11%%", (lo, hi) == (PUB["spread_lo"], PUB["spread_hi"]),
          "min=%.4f max=%.4f (at 2dp: %.2f-%.2f)" % (min(rates), max(rates), lo, hi))

    # ---- 4. the controls ----------------------------------------------------------------------
    print("\nCONTROLS (V0<->V2 and V1<->V3 on NON-DECOMPOSABLE cases; MANUSCRIPT.md:183-189)")
    for a, b in (("V0", "V2"), ("V1", "V3")):
        n = same = 0
        for m in models:
            for c in cases:
                ra, rb = idx.get((m, a, c)), idx.get((m, b, c))
                if not ra or not rb or ra["decomposable"]:
                    continue
                n += 1
                same += ra["picked_index"] == rb["picked_index"]
        check("%s<->%s non-decomposable %d/%d identical" % (a, b, PUB["control_identical"], PUB["control_n"]),
              (same, n) == (PUB["control_identical"], PUB["control_n"]),
              "measured identical=%d/%d divergent=%d" % (same, n, n - same))

    # ---- 5. prompt-level divergence ----------------------------------------------------------
    print("\nPROMPT DIVERGENCE (each model, V0 vs V1; MANUSCRIPT.md:172)")
    pn = pd = 0
    for m in models:
        for c in cases:
            pn += 1
            pd += idx[(m, "V0", c)]["picked_index"] != idx[(m, "V1", c)]["picked_index"]
        n_c = sum(1 for c in cases if idx[(m, "V0", c)]["picked_index"] != idx[(m, "V1", c)]["picked_index"])
        print("       %-14s V0 vs V1 divergent %d/190 = %.4f%%" % (m, n_c, rate(n_c, 190)))
    check("prompt pooled == %d/%d = %.4f%%" % (PUB["prompt_n"], PUB["prompt_d"], PUB["prompt_rate"]),
          (pd, pn) == (PUB["prompt_n"], PUB["prompt_d"]) and
          abs(rate(pd, pn) - PUB["prompt_rate"]) <= TOL,
          "measured %d/%d = %.4f%%" % (pd, pn, rate(pd, pn)))

    # ---- 6. l1-head-to-head ------------------------------------------------------------------
    print("\nL1 HEAD-TO-HEAD (l1-head-to-head.jsonl; MANUSCRIPT.md:234)")
    lmodels = sorted({r["model"] for r in l1})
    ids = sorted({r["id"] for r in l1})
    a, b = lmodels
    dis = sum(li[(a, c)]["picked_index"] != li[(b, c)]["picked_index"] for c in ids)
    check("l1 %s vs %s == %d/%d = %.4f%%" % (b, a, PUB["l1_n"], PUB["l1_d"], PUB["l1_rate"]),
          (dis, len(ids)) == (PUB["l1_n"], PUB["l1_d"]) and
          abs(rate(dis, len(ids)) - PUB["l1_rate"]) <= TOL,
          "measured %d/%d = %.4f%%" % (dis, len(ids), rate(dis, len(ids))))
    same = {m: sum(idx[(m, "V0", c)]["picked_index"] == li[(m, c)]["picked_index"] for c in ids)
            for m in lmodels}
    check("l1 picks are the V0 picks, 190/190 per model (same 98 disagreements)",
          all(v == 190 for v in same.values()), "%s" % same)
    for m in lmodels:
        acc = sum(li[(m, c)]["picked_index"] == li[(m, c)]["correct"] for c in ids)
        print("       %-14s picked_index==correct %d/%d = %.4f%%" % (m, acc, len(ids), rate(acc, len(ids))))

    # ---- 7. the stimulus fixture: NOT shipped in this package --------------------------------
    print("\nSTIMULUS FIXTURE (not shipped here; released with the companion note, Zenodo concept"
          " DOI 10.5281/zenodo.23463944; MANUSCRIPT.md section 7)")
    fxp = os.path.join(ROOT, "fixture", "fixture-190.json")
    if os.path.isfile(fxp):
        fx = jload("fixture", "fixture-190.json")
        check("fixture has 190 cases", len(fx) == 190, "cases=%d" % len(fx))
        bad = [c["id"] for c in fx
               if not (isinstance(c["correct"], int) and not isinstance(c["correct"], bool)
                       and 0 <= c["correct"] < len(c["options"]))]
        check("fixture `correct` is an in-range option index",
              not bad and len({len(c["options"]) for c in fx}) > 1,
              "out-of-range=%d, option-counts=%s"
              % (len(bad), sorted({len(c["options"]) for c in fx})))
        check("fixture ids are disjoint from record ids by design",
              not (set(c["id"] for c in fx) & set(cases)),
              "overlap=%d" % len(set(c["id"] for c in fx) & set(cases)))
    else:
        print("       absent: the record-derived numbers above are this package's closure; the")
        print("       fixture is not needed for them (deleting it leaves them intact -- cut ladder).")

    # ---- verdict, folded into the exit code ---------------------------------------------------
    npass = sum(1 for _, ok in CHECKS if ok)
    print("\nCHECKS: %d/%d passed" % (npass, len(CHECKS)))
    for name, ok in CHECKS:
        if not ok:
            print("  FAILED: %s" % name)
    ok = npass == len(CHECKS)
    print("ALL PUBLISHED NUMBERS REPRODUCED:", ok)
    print("VERDICT:", "PASS" if ok else "FAIL")
    if os.path.isfile(fxp):
        print("fixture correctness digest:",
              hashlib.sha256(json.dumps([[c["id"], c["correct"], len(c["options"])] for c in fx],
                                        separators=(",", ":")).encode()).hexdigest())
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
