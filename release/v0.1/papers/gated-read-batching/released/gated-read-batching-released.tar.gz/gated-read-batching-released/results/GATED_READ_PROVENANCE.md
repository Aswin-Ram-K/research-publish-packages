# Gate provenance — literature provenance for the binary read-gate experiment

**Research question.** Where does the "true/false decision gating a tool call" pattern come from, and where
does the "decision model combs a file listing and stages a shortlist in front of a reasoning model" pattern
come from — so the experiment can be positioned against prior art instead of presented as invented.

**Method.** `web_search` is unavailable in this session (`DEEPSEEK_API_KEY` missing); all sources were found with
`local_web_search` (SearXNG) and arXiv's export API, then **fetched directly** (`curl` + `pdftotext`/HTML strip).
Only URLs actually fetched and read are listed. House rule applied: no unverified DOIs; a prompt is a citation too.

**Verification discipline (and what it caught).** Four arXiv IDs recalled from memory were wrong and were caught by
fetching the record rather than trusting it: `2212.09561` (that is *Large Language Models are Better Reasoners with
Self-Verification*, not Mallen et al. → correct `2212.10511`), `2302.00013` (a particle-physics paper, not TALM →
correct `2205.12255`), `2312.10997` (that is the RAG survey, not ToolEmu → correct `2309.15817`), and `2403.10131`
(that is RAFT, not the function-calling leaderboard paper). Every citation below is from a fetched record.

**Legend:** **P** = primary (paper/repo/docs), **S** = secondary (blog/index page).

---

## 1. Master table

| source | year | what it established (verified) | relevance to our binary read-gate |
|---|---|---|---|
| **Toolformer** — Schick, Dwivedi-Yu, Dessì, Raileanu, Lomeli, Hambro, Zettlemoyer, Cancedda, Scialom (P: arXiv 2302.04761; P: NeurIPS 2023 proceedings) | 2023 | LM "trained to decide **which APIs to call, when to call them**"; calls kept only if they "reduce the loss L_i over the next tokens" (self-supervised binary worth-call filter) | The canonical "model itself decides whether a tool call is worth inserting" — but the decision is **loss-based, not purpose-based**, and the paper's own limitation says it ignores tool cost |
| **TALM** — Parisi, Zhao, Fiedel (P: arXiv 2205.12255) | 2022 | "Tool Augmented Language Models" with an iterative self-play bootstrapping from few tool demonstrations | **The earlier antecedent, named by Toolformer itself** as "most closely related … a similar self-supervised objective" — so the binary tool-worth decision predates Toolformer by ~9 months |
| **SayCan** — Ahn et al. (P: arXiv 2204.01691) | 2022 | LM-proposed skills scored by "value functions … that provide the grounding necessary to connect this knowledge to a particular physical environment" | Earlier likelihood×applicability gate on whether an action is worth taking (ranking, not a binary gate; robot skills, not file reads) |
| **Self-RAG** — Asai, Wu, Wang, Sil, Hajishirzi (P: arXiv 2310.11511) | 2023 | Model "first determines if augmenting the continued generation with retrieved passages **would be helpful**. If so, it outputs a retrieval token"; retrieval fires when P(Retrieve=Yes) passes a threshold; `IsRel` marks each passage Relevant/Irrelevant | The direct ancestor of a **binary retrieve-needed** gate and of a **binary relevance** judgment on retrieved content |
| **Mallen et al.**, *When Not to Trust LMs* (P: arXiv 2212.10511, ACL 2023) | 2022 | "retrieves non-parametric memories **only when necessary** … improves performance while reducing the inference costs" | Earliest verified retrieve-or-not gate (Dec 2022), framed explicitly as cost-vs-accuracy |
| **FLARE** — Jiang et al. (P: arXiv 2305.06983, EMNLP 2023) | 2023 | "methods that actively decide **when and what** to retrieve … retrieve relevant documents to regenerate the sentence if it contains low-confidence tokens" | Per-step confidence gate on retrieval (token-level analogue of a binary gate) |
| **Adaptive-RAG** — Jeong, Baek, Cho, Hwang, Park (P: arXiv 2403.14403, NAACL 2024) | 2024 | "selection process is operationalized with **a classifier, which is a smaller LM** trained to predict the complexity level of incoming queries" across no-retrieval / single-step / iterative strategies | **Closest structural precedent for a cheap decision model staged in front of a larger pipeline** — but the unit is a *query*, not a file read |
| **OpenAI Function calling guide** (P: platform.openai.com docs) | 2025/26 | "By default the model will determine when and how many tools to use… **Auto (Default): Call zero, one, or multiple functions**"; `tool_choice:"none"` imitates passing no functions; `parallel_tool_calls:false` ⇒ "exactly zero or one tool is called" | No-tool-call is an explicit, supported **legitimate output** of the model, not an error path |
| **Anthropic — Tool use with Claude** (P: docs.anthropic.com) | 2025/26 | "With the default `tool_choice` of `{"type":"auto"}`, **Claude determines on each turn whether to call a tool or respond directly**. It calls a tool when the request maps to that tool's described capability and the answer isn't already in context." | Intent gating before invocation is *the documented default semantics*, with `auto`/`none`/`any`/`tool` modes |
| **BFCL (Gorilla) relevance detection** (P: gorilla.cs.berkeley.edu home + BFCL blog) | 2023–24 | "we design scenarios where **none of the provided functions are relevant** … We expect the model's output to be **no function call**"; also a "Chatting Capability" category where the model must "recognize that it does not need to invoke any functions" | Intent-gating **is** evaluated: binary "should I call at all" scored on a public leaderboard |
| **API-Bank** — Li et al. (P: arXiv 2304.08244, EMNLP 2023) | 2023 | "314 tool-use dialogues with 753 API calls to assess the existing LLMs' capabilities in **planning, retrieving, and calling** APIs" | Benchmark for deciding *which* call (or none) before execution |
| **Llama Guard** — Inan et al. (P: arXiv 2312.06674) | 2023 | "a language model, carrying out multi-class classification and **generating binary decision scores**" over prompts/responses under a risk taxonomy | The canonical guard-classifier shape (binary verdict in front of a conversation), applied to text, **not** to proposed tool calls |
| **GuardAgent** — Xiang et al. (P: arXiv 2406.09187, ICML 2025) | 2024 | "dynamically checking **whether their actions satisfy** given safety guard requests"; "over 98% and 83% guardrail accuracies" on two agent benchmarks | Pre-action classifier gate with reported accuracy — but the criterion is *safety policy*, not task relevance |
| **ShieldAgent** — Chen, Kang, Li (P: arXiv 2503.22738) | 2025 | Scores whole **action trajectories** against explicit policies; "outperforming prior methods by 11.3% … high recall of 90.1% … reduces API queries by 64.7%" | Guard layer over agent actions; cost/latency numbers reported, relevance not covered |
| **CaMeL** — Debenedetti et al., *Defeating Prompt Injections by Design* (P: arXiv 2503.18813) | 2025 | "uses a notion of a capability to prevent the exfiltration of private data over unauthorized data flows by **enforcing security policies when tools are called**"; 77% vs 84% task success on AgentDojo | A **system layer that vets a call before it executes**, with a measured security/utility trade-off |
| **ToolEmu** — Ruan et al. (P: arXiv 2309.15817) | 2023 | LM-emulated tool execution + "LM-based automatic safety evaluator"; "even the safest LM agent exhibits such failures **23.9% of the time**" | Evidence that un-gated tool use fails at measurable rates (motivation for a gate) |
| **Claude Code — Configure permissions** (P: code.claude.com/docs/en/permissions) | 2026 | Rules are **tool+path patterns** (`Read(./.env)`, `Bash(aws *)`), modes `ask/allow/deny`, precedence "A broad deny rule … blocks every matching call"; under `dontAsk`, "**file reads in your working directories** and other actions that need no approval **still run**" | **Reads are gated by permission/path, never by relevance** — the clearest negative control for our claim |
| **Claude Code — auto mode** (P: code.claude.com/docs/en/auto-mode-config.md) | 2026 | "routing tool calls through **a classifier** that blocks anything irreversible, destructive, or aimed outside your environment. Deny and explicit ask rules are evaluated before the classifier" | A live, shipped **pre-tool-call classifier gate** (safety/permission criterion, not read relevance) |
| **OpenAI — Guardrails and human review** (P: platform.openai.com/docs/guides/agents/guardrails-approvals) | 2026 | "**Guardrails validate input, output, or tool behavior automatically**"; "Tool guardrails — Pause before side effects like cancellations, edits, shell commands…"; "Human review pauses the run so a person or policy can approve or reject a sensitive action" | Product-level confirmation that pre-action approval/guard gates are standard; criterion = side-effect risk |
| **RouteLLM** — Ong, Almahairi, Wu, Chiang, Wu, Gonzalez, Kadous, Stoica (P: arXiv 2406.18665, ICLR 2025) | 2024 | Routers "dynamically select between a **stronger and a weaker LLM**"; "reduces costs by over 2 times in certain cases without compromising quality"; "cost savings of **up to 3.66x**"; APGR computed "by varying the threshold values α" | The reference **binary routing decision with a measured accuracy-vs-cost curve** — the template for our gate's evaluation |
| **FrugalGPT** — Chen, Zaharia, Zou (P: arXiv 2305.05176) | 2023 | "**98% cost reduction** or improve the accuracy over GPT-4 by 4% with the same cost" via prompt adaptation, LLM approximation, **LLM cascade** | Established that a cheap front decision in front of an expensive model is worth measuring on both axes |
| **semantic-router** (P: aurelio-labs/semantic-router README) | 2023–26 | "a superfast **decision-making layer** for your LLMs and agents. Rather than waiting for slow LLM generations to make tool-use decisions, we use … semantic vector space to make those decisions" | Non-LLM embedding router in front of tool use — the low-cost baseline any read-gate must beat |
| **Inside the Scaffold** — Rombaut (P: arXiv 2604.03515) | 2026 | Source-code taxonomy of **13 coding-agent scaffolds**; §4.2.4 gives 7 context-retrieval strategy types: keyword/regex (SWE-agent, OpenHands, Codex CLI, Gemini CLI, Cline, mini-swe-agent, DARS-Agent, OpenCode), repo map (Aider), AST search (AutoCodeRover…), knowledge graph (Prometheus), embeddings (Moatless — "the only agent with embedding-based retrieval as an LLM-callable tool"), hierarchical localization (Agentless), fault localization | **The strongest evidence for the gap:** file relevance is decided by search/rank/retrieval machinery or by free LLM tool choice — no per-read binary classifier anywhere in the 13 |
| **Aider repo map** (P: aider.chat/docs/repomap.html + `aider/repomap.py` on GitHub) | 2023–26 | "Aider solves this problem by sending just the **most relevant portions** of the repo map … a graph ranking algorithm"; "the LLM can use the map to figure out which files it needs to look at"; source: `mul *= 10` for mentioned identifiers, `use_mul *= 50` for chat files | Relevance decided by **deterministic ranking under a token budget**, ahead of any read — the design most adjacent to ours, but not a model decision and not measured as a classifier |
| **Cursor codebase indexing** (P: cursor.com/blog/secure-codebase-indexing) | 2024/26 | "Cursor splits it into syntactic chunks. These chunks are converted into the embeddings that enable **semantic search**" | Relevance gating lives at the **embedding/retrieval layer**, not at the individual read |
| **SWE-agent** — Yang et al. (P: arXiv 2405.15793) | 2024 | "custom agent-computer interface (ACI) significantly enhances an agent's ability to create and edit code files, **navigate entire repositories**, and execute tests" | Navigation via curated commands (a *capability* gate), not a relevance decision on each read |
| **RAFT** — Zhang et al. (P: arXiv 2403.10131) | 2024 | "we train the model to **ignore those documents that don't help** in answering the question, which we call, distractor documents" | Trained per-document relevance filtering — in RAG context assembly, not agent file reads |
| **Batch Prompting** — Cheng, Kasai, Yu (P: arXiv 2301.08721, EMNLP 2023 Industry) | 2023 | "inference costs decrease **almost inverse linearly** with the number of samples in each batch … up to 5x with six samples in batch … while achieving better or comparable performance"; "the number of samples in each batch and the complexity of tasks affect its performance" | The cost case **for** batching many decisions into one request |
| **BatchPrompt** — Lin, Diesendruck, Du, Abraham (P: arXiv 2309.00384) | 2023 | "**prompting with batched data in longer contexts will inevitably lead to worse performance**, compared to single-data prompting"; accuracy falls with batch size; strong position effects | The accuracy case **against** naive batching — the measured delta we must reproduce/control |
| **Efficient but Vulnerable** — Yue & Yao (P: aclanthology.org/2025.findings-acl.245 + arXiv 2503.15551, Findings of ACL 2025) | 2025 | "Batch prompting … combines a batch of multiple queries sharing the same context in one inference"; cross-query interference lets one item perturb the others; probing defense detects attacks at ">95% accuracy" | Documents that batched decisions are **coupled** — a failure mode unique to the batched design |
| **RoBatch** (P: arXiv 2605.28268) | 2026 | Joint routing+batching; "As the batch sizes grow, the result quality can degrade"; models "**utility degradation with batching**" explicitly | Confirms batching-vs-utility is an active measured axis, still without a per-read-gate use case |

---

## 2. Sub-question detail

### 2.1 Tool-use decisions as binary/likelihood choices
**Canonical:** Toolformer (Schick et al., 2023; verified in NeurIPS 2023 proceedings *and* arXiv).
Verified quotes: "a model trained to decide which APIs to call, when to call them, what arguments to pass, and how to
best incorporate the results into future token prediction. This is done in a self-supervised way…"; the filter is
mechanical — "filter out all calls which do not reduce the loss L_i over the next tokens"; Fig. 1 caption: "The model
autonomously decides to call different APIs".

**Earlier antecedent — yes, and Toolformer names it:** "Perhaps most closely related to our work is **TALM
(Parisi et al., 2022)**, an approach that uses a similar self-supervised objective for teaching a model to use a
calculator and a search engine, but explores this only in settings where a model is finetuned for downstream tasks."
TALM verified as arXiv 2205.12255 (Parisi, Zhao, Fiedel, 2022). SayCan (2204.01691, 2022) is an independent earlier
"value function" gate on whether a proposed action is applicable.

**Useful contrast for the experiment:** Toolformer's own limitations section states "when deciding whether or not to
make an API call, Toolformer currently does not take into account the tool-dependent, computational cost incurred from
making an API call." Our gate is explicitly *purpose-conditioned* and *cost-measured*, which Toolformer is not.

### 2.2 "Retrieve or not" gating
- **Self-RAG** (verified): "S ELF -R AG first determines if augmenting the continued generation with retrieved passages
  would be helpful. If so, it outputs a retrieval token that calls a retriever model on demand"; inference uses "the
  probability of generating the `Retrieve=Yes` token normalized over all output tokens … surpasses a designated
  threshold, we trigger retrieval"; Table 1 defines four reflection-token families, including `Retrieve` (Yes/No) and
  the critique tokens `IsRel` (Relevant/Irrelevant), `IsSup`, `IsUse`. Appendix examples show `[Retrieve=No]` and
  `[IsRel=Relevant]` emitted inline — i.e. **both a gate and a per-item relevance judgment in one generation**.
- **Mallen et al. (ACL 2023, 2212.10511)** — earlier (Dec 2022): retrieval "only when necessary", sold as performance
  *and* cost.
- **Adaptive-RAG (NAACL 2024)** — a *smaller LM classifier* predicts query complexity and selects no-retrieval /
  single-step / iterative. This is the closest published relative of "a decision model in front of a bigger component".
- **FLARE (EMNLP 2023)** — per-generation-step confidence gate.

### 2.3 Function-calling modes where "no call" is a legitimate output
- **OpenAI** (fetched): `auto` = "Call zero, one, or multiple functions" (default: "the model will determine when and
  how many tools to use"); `required` = "Call one or more functions"; "You can also set `tool_choice` to `none` to
  imitate the behavior of passing no functions"; with `parallel_tool_calls: false`, "exactly zero or one tool is
  called". The guide also documents **deferred tools / tool search**, "so deferred tools are loaded only when needed".
- **Anthropic** (fetched): default `auto` — "Claude determines on each turn whether to call a tool or respond directly";
  modes `auto`/`none`/`any`/`tool`.
- **Evaluated intent-gating:** BFCL/Gorilla (official site + blog, both fetched) defines **Function Relevance
  Detection**: "we design scenarios where none of the provided functions are relevant and supposed to be invoked.
  We expect the model's output to be **no function call**." Plus a Chatting category where the model must recognise
  "it does not need to invoke any functions". API-Bank (EMNLP 2023) evaluates planning/retrieving/calling.
  → **Prior art exists for evaluating the binary call/abstain decision — over a *tool set*, not over a file.**

### 2.4 Pre-tool-call policy/permission gates as classifiers
- **Claude Code auto mode (docs):** "routing tool calls through **a classifier** that blocks anything irreversible,
  destructive, or aimed outside your environment."
- **Claude Code permissions (docs):** permission modes (`default` prompts on first use; `plan` — "classifier-approved
  commands also run"; `dontAsk` — "file reads in your working directories … still run"), rules like `Read(./.env)`,
  deny-over-allow precedence.
- **OpenAI guardrails (docs):** "Guardrails validate input, output, **or tool behavior** automatically"; "Tool
  guardrails — pause before side effects…"; human review "approve[s] or reject[s] a sensitive action".
- **Papers:** Llama Guard (binary/multi-class scores, but on prompt/response text), GuardAgent (98%/83% guardrail
  accuracy), ShieldAgent (90.1% recall, −64.7% API queries), CaMeL (capability checks *before* tool execution, 77% vs
  84%), ToolEmu (23.9% failure rate even for the safest agent).
- **Not found:** an Anthropic *documentation page* specifically for a tool-call safety classifier. The current Anthropic
  docs index (`docs.anthropic.com/llms.txt`, fetched) has a "strengthen-guardrails" section covering jailbreaks,
  hallucinations, prompt leak, refusals — no tool-specific guardrail page. [NOT FOUND in this session]

### 2.5 Router/cascade decisions
RouteLLM (ICLR 2025) is the template: a **binary** strong/weak decision, evaluated as a threshold sweep
("call-performance graph … varying the threshold values α", APGR), with "over 2×" cost reduction and "up to 3.66x"
savings "while maintaining response quality". FrugalGPT gives the headline "98% cost reduction or +4% accuracy".
semantic-router is the non-LLM embedding baseline explicitly positioned as making "tool-use decisions" without an
LLM call. All three decide over **queries/prompts**, never over individual file reads.

### 2.6 File-read relevance gating specifically — what the evidence actually shows
**What clearly exists:**
1. **Retrieval/rank-level gating.** Aider computes a PageRank-weighted repo map under a token budget and ships "the
   most relevant portions" (docs verified; code verified: `mul *= 10` for mentioned identifiers, `use_mul *= 50` for
   chat files at `aider/repomap.py`). Cursor embeds chunks for semantic search (official blog verified). Moatless is
   "the only agent with embedding-based retrieval as an LLM-callable tool". Agentless narrows
   file → class/function → line across stages; AutoCodeRover uses spectrum-based fault localization. Eight of thirteen
   scaffolds delegate to `grep`/`find`/`ripgrep` tool calls (taxonomy §4.2.4, Table 8).
2. **Permission-level gating of reads.** Claude Code matches `Read(path)` rules and modes; `dontAsk` explicitly still
   runs working-directory file reads. Criterion = *may this path be read*, not *is this file relevant*.
3. **Free LLM navigation.** Taxonomy §4.1.2: in nine of thirteen agents "the LLM [has] full autonomy over tool
   selection"; for Aider, "the LLM never runs grep, never opens a file it was not given, and never decides 'I should
   look at module Y'" — navigation is the user's.

**No direct prior art found** for: *a binary relevance decision — conditioned on (task, intended read purpose, file) —
executed immediately before an individual file read, evaluated as a classifier with labelled data, and measured for
accuracy/cost/coverage.* Every mechanism found is either upstream (search/rank/embedding), sideward (permission/path),
or downstream (the reasoner chooses after seeing search results). [INFERENCE from the searches listed in §5 — searched
absence, not measured absence.]

### 2.7 Batched decision evaluation
See §4.

---

## 3. Gap statement

**Clearly exists today**
- A model deciding, at generation time, *whether* to call a tool at all (Toolformer, TALM; `auto`/`none` semantics in
  OpenAI and Anthropic docs) — and public evaluation of that abstain decision (BFCL relevance detection, API-Bank).
- A binary retrieve-needed decision plus a per-passage relevance token (Self-RAG), and thresholded retrieval gating
  (Self-RAG, Mallen, FLARE).
- A small classifier staged in front of a larger pipeline, with a quality–cost curve (Adaptive-RAG; RouteLLM's
  threshold-swept APGR; FrugalGPT's cascade; semantic-router's embedding router).
- Pre-action guard classifiers over *proposed or executed actions*, with reported accuracy (GuardAgent, ShieldAgent,
  Claude Code's auto-mode classifier, OpenAI tool guardrails, CaMeL) — criterion is safety/permission, never task
  relevance for a read.
- Retrieval-level file relevance (Aider repo map ranking, Cursor embeddings, AST/keyword search, hierarchical and
  fault-localization selection) — i.e. **harnesses already gate what reaches the context, but at the search/rank layer.**
- Batching many decisions into one request, with measured cost savings *and* measured accuracy losses (§4).

**What appears NOT to exist yet**
1. **Per-file-read relevance gating as a measured component**: no found system or paper puts a binary
   "is this file relevant *for this purpose*" classifier between the agent and an individual `Read`, and reports its
   accuracy, its effect on downstream task success, or its cost. Gating of reads that does exist is *permission/path*
   gating (Claude Code) or *absence* of gating.
2. **Purpose-conditioned relevance.** Self-RAG's `IsRel` is passage-vs-query; BFCL relevance is tool-vs-question; none
   conditions on the *intended read purpose* (why this file is about to be opened).
3. **A decision layer that stages a shortlist from a file listing for a downstream reasoner.** The nearest analogues
   stage *queries* (Adaptive-RAG, RouteLLM) or *context tokens* (Aider's map under a budget); none stages *candidate
   file reads* as an explicit, measured shortlist decision.
4. **Batching evidence specific to binary gating decisions.** Published batch-prompting numbers come from QA/NLI
   classification tasks; none isolates "N independent yes/no gate decisions in one request" — so our batching arm would
   be the first measured instance rather than a replication.
5. **Read-gating on the cost axis.** Toolformer explicitly does not account for tool cost; no found source prices
   individual reads against a budget as part of the gate decision.

**Positioning sentence for the brief/experiment:** the *mechanism* (binary decision in front of an action) is
well-trodden — Toolformer/Self-RAG/OpenAI `tool_choice`/RouteLLM own that; the *unit of decision* (an individual file
read, conditioned on intended read purpose) and its *measurement* (accuracy of the gate itself plus effect on task
success and token cost) do not appear in the sources below.

---

## 4. Batching evidence (with numbers)

**Setup in the literature:** "batch prompting … packs multiple queries into a single invocation to amortize the fixed
cost of the shared system prompt" (RoBatch, arXiv 2605.28268).

**Case FOR batching (cost):**
- *Batch Prompting* (Cheng, Kasai, Yu; arXiv 2301.08721; EMNLP 2023 Industry Track): "the inference costs decrease
  **almost inverse linearly** with the number of samples in each batch"; "up to **5x** with six samples in batch
  [reduces] the LLM (Codex) inference token and time costs **while achieving better or comparable performance**" over
  ten datasets; benefits also hold for GPT-3.5/GPT-4. Caveat in the same abstract: "**the number of samples in each
  batch and the complexity of tasks affect its performance**."
- *BatchPrompt* cost accounting (arXiv 2309.00384): at batch size 32 with five voting rounds, input tokens fall
  **72.6% / 81.4% / 69.2%** and LLM calls fall **84.4% / 90.6% / 84.4%** on BoolQ / QQP / RTE.

**Case AGAINST naive batching (accuracy deltas):**
- *BatchPrompt* abstract: "prompting with batched data in longer contexts will **inevitably lead to worse performance**,
  compared to single-data prompting", and "the performance … is significantly correlated with the **positions and
  order** of the batched data."
- Measured deltas vs one-question-per-call (`SinglePrompt`):
  - **BoolQ: 90.6% (single) → 72.8% (batched, batch size ≥64, no ensembling) = −17.8 points**; with more voting
    rounds it climbs back to **86.3% (still −4.3)**. ("When batch size is equal to or higher than 64, BatchPrompt
    cannot perform well without BPE … the accuracy on Boolq is only 72.8%, while SinglePrompt is 90.6%. However,
    with more voting rounds, the accuracy of BatchPrompt can smoothly increase to 86.3%.")
  - **GSM8K: 94.9% (single) → 89.1% (batch size 32, one round) = −5.8 points**, recovering to 92.0% at five rounds.
  - Generalised: "prompting with larger batch size generally produces worse results. When batch size is 64,
    accuracies for **all** datasets decrease significantly with one voting round."
  - With the paper's fixes at batch size 32 (five rounds): BoolQ **90.6 → 90.9**, QQP **87.2 → 88.4**, RTE
    **91.5 → 91.1** while using **9–16% of the LLM calls** — i.e. batching lands within roughly **±1.2 points** of
    one-call-per-question *only after* permutation + ensembling + early stopping.
- Position effects: "data putting at the very beginning or end can get better performance" (their Fig. 1), the usual
  mid-context deficit.
- **Completion/yield failure unique to batching:** "Not using the index or just use a delimiter … will result in the
  **missing of answers (e.g., 15 generated answers when input batch size is 16)**" — a batched gate can silently drop
  decisions. This is the failure mode to instrument first.
- **Coupling:** *Efficient but Vulnerable* (Yue & Yao, Findings of ACL 2025): a batch shares one context, so one item
  perturbs the others; their probing defense detects such batches at ">95% accuracy"; their Table 2 finds attack
  impact "does not have a major impact" from batch size itself, i.e. the risk is cross-talk, not size alone.
- **Current framing:** *RoBatch* (2605.28268) explicitly models "recalibration of model-specific **utility degradation
  with batching**" and states "as the batch sizes grow, the result quality can degrade, especially when the input
  prompt exceeds the effective context window."

**Bottom line for our design:** the literature gives a real, reproducible trade — roughly an order of magnitude fewer
calls/tokens for a **−4 to −18 point** accuracy cost under naive batching, closed to ≈±1 point only with
permutation/ensembling machinery. No source isolates binary gate decisions, so that delta would be **newly measured**,
not replicated.

---

## 5. Verification notes / what is NOT claimed

**Not verified / not found (explicitly marked):**
- [UNVERIFIED] arXiv identifier for the Berkeley Function-Calling Leaderboard *paper*. The **official blog and site
  were fetched** and support every BFCL claim quoted above; only the paper ID is unresolved (arXiv API rate-limited /
  flaky search during this session).
- [NOT FOUND] An Anthropic documentation page dedicated to a tool-call safety classifier. Anthropic's tool-use docs
  (fetched) cover `tool_choice` gating; the docs index (fetched) has no tool-specific guardrail page.
- [UNVERIFIED] Self-RAG's conference venue (arXiv record carries no venue comment; an ICLR proceedings PDF appeared in
  a search result but was not fetched).
- [INFERENCE] Every "no prior art for per-file-read relevance gating" claim is **searched absence**, based on the
  taxonomy of 13 scaffolds plus harness docs fetched here — not a systematic review.
- Secondary sources used only for URL discovery, never as claim support (search-engine snippets).
- Cursor's docs site is a JS app; the fetched page returned only navigation. The **official Cursor engineering blog**
  was fetched instead and supports the embedding/semantic-search claim.

**Recalled-ID corrections caught by fetching** (recorded per house rule): `2212.09561`, `2302.00013`, `2312.10997`,
`2403.10131` all resolved to different papers than intended; corrected to `2212.10511`, `2205.12255`, `2309.15817`,
and (RAFT, kept as its own verified citation).

**URLs fetched and confirmed (all quoted content came from these):**
`arxiv.org/abs/2302.04761`, `arxiv.org/pdf/2302.04761`, `papers.nips.cc/paper_files/paper/2023` (Toolformer entry),
`arxiv.org/abs/2205.12255`, `arxiv.org/abs/2204.01691`, `arxiv.org/pdf/2310.11511`, `arxiv.org/abs/2310.11511`,
`arxiv.org/abs/2212.10511`, `arxiv.org/abs/2403.14403`, `arxiv.org/abs/2305.06983`,
`platform.openai.com/docs/guides/function-calling`, `docs.anthropic.com/en/docs/build-with-claude/tool-use/overview`,
`docs.anthropic.com/llms.txt`, `gorilla.cs.berkeley.edu/`, `gorilla.cs.berkeley.edu/blogs/8_berkeley_function_calling_leaderboard.html`,
`arxiv.org/abs/2304.08244`, `arxiv.org/abs/2312.06674`, `arxiv.org/abs/2406.09187`, `arxiv.org/abs/2503.22738`,
`arxiv.org/abs/2503.18813`, `arxiv.org/abs/2309.15817`, `code.claude.com/docs/en/permissions`,
`code.claude.com/docs/en/auto-mode-config.md`, `code.claude.com/docs/en/llms.txt`,
`platform.openai.com/docs/guides/agents/guardrails-approvals`, `arxiv.org/abs+pdf/2406.18665`,
`arxiv.org/abs/2305.05176`, `raw.githubusercontent.com/aurelio-labs/semantic-router/main/README.md`,
`arxiv.org/abs+html/2604.03515`, `aider.chat/docs/repomap.html`, `raw.githubusercontent.com/Aider-AI/aider/main/aider/repomap.py`,
`cursor.com/blog/secure-codebase-indexing`, `arxiv.org/abs/2405.15793`, `arxiv.org/abs+html/2309.00384`,
`arxiv.org/abs/2301.08721`, `aclanthology.org/2025.findings-acl.245`, `arxiv.org/html/2503.15551`,
`arxiv.org/abs+html/2605.28268`, `arxiv.org/abs/2403.10131`.

**Scope note:** gathering this provenance modified no source file. The fetch tooling used was
author-side and disposable; it is not part of this deposit.
