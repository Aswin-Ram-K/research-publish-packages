# Replay reproduces the record, not the decision — data + verification tool

Release package for paper #2. It ships **exactly the bytes the
published numbers need**, and a checker that re-derives every one of them.

The companion release (paper #3) is at Zenodo concept DOI
`10.5281/zenodo.23463944`; this package is deliberately **not** a copy of that one — it is the
smallest set of bytes from which this paper's claims follow. **The stimulus fixture is not shipped
here**: it releases with the companion note and is referenced, not copied.

## What ships

| path | bytes | sha256 |
|---|---|---|
| `data/decision-variants.jsonl` | 1,197,797 | `c5ec44a799ddeb963f862fc5c054ddad6ef2fce6ad90edfafd7c1755ac4370e7` |
| `data/l1-head-to-head.jsonl` | 63,238 | `6af0e0d8294cf4d7a20e2d8cb9bfe0c11ff70cc4c4b2792fcdedaf9246b2a1e7` |
| `verify/recompute-claims.py` | 13,936 | see `MANIFEST.json` (authored here) |
| `README.md`, `LICENSE`, `COMMERCIAL.md`, `CONTRIBUTING.md` | — | see `MANIFEST.json` |

### `data/` — the two record files

`decision-variants.jsonl` is 3,040 rows = **4 models × 190 cases × 4 variants**, one row per
(model, variant, case). `l1-head-to-head.jsonl` is 380 rows = 2 models × 190 cases. Both are shipped
**byte-identical to source** (`identical_to_source: true` in `MANIFEST.json`); no row, field or byte
is added, removed or renamed.

**`correct` is an option index, not a flag** — in both files it holds an integer in 0–4, and
`l1-head-to-head.jsonl` line 1 is a *wrong* answer whose `correct` field is literally `0`. The
outcome axis is therefore the derived predicate `picked_index == correct`. `verify/recompute-claims.py`
checks this explicitly and prints both readings side by side: summing `correct` as a flag gives
`1.0632` "accuracy" where the truth is `0.4500`.

### The stimulus fixture is NOT in this package — it releases with the companion note

This package carries the two record files and the checker, and **no fixture**. The stimulus — the
questions, the option texts and the hand-authored labels — releases with the **companion note** on
Zenodo, concept DOI **`10.5281/zenodo.23463944`** (the companion release, paper #3); it is
referenced here, not copied. (An earlier draft shipped a copy of the companion fixture; it was removed
because shipping paper #3's fixture inside this package contradicted this paper's own §7 availability
boundary.)

**Correspondence, stated plainly.** The companion fixture carries the **same 190 cases** as these
records, with the **same per-kind counts** (30/30/26/22/26/28/28), under a **different neutralised
tagging** (the companion tags its kinds `K01 K02 K03 K04 K05 K07 N10`; the records use their own kind
names). The case order within a kind is the same on both sides, and the tag correspondence is
recoverable from the data itself: ordering each kind's cases by numeric suffix, the per-kind sequence
of `correct` values determines the mapping **uniquely** — exactly one bijection of the seven kinds
matches all seven sequences. Neither release states that mapping as a table, so it must be recovered
by that rule. The re-derivation was carried out author-side; the script is not distributed with this
package, so a reader who wants to redo it must implement the rule just stated.

**The two corpora are not independent.** The companion fixture is the same case set, not a second
sample. The headline numbers do not depend on the fixture at all: the cut-ladder re-run drops
`data/decision-variants.jsonl` and `data/l1-head-to-head.jsonl` (each breaks the closure); the fixture
is already absent and changes nothing. (The cut ladder is author-side build tooling and is not
distributed.)

### `verify/recompute-claims.py`

Standard library only. Re-derives, from the shipped bytes: **476/1,140 = 41.7544 %** binding
divergence at V0; the per-variant rates **41.7544 / 47.1053 / 40.0000 / 43.3333 %** (spread
40.00–47.11); the non-decomposable controls **244/244 identical** for both V0↔V2 and V1↔V3;
prompt-level **245/760 = 32.2368 %**; `l1` **98/190 = 51.5789 %**; outcome divergence
**324/1,140 = 28.4211 %**; and the `correct`-column trap.

```bash
python3 verify/recompute-claims.py     # exit 0 == every published number reproduced
```

**Every comparison is folded into the exit code.** A check that is computed but not folded into the
exit status is the exact defect this script exists to avoid; `VERDICT: FAIL` and exit `1` are the same
event here.

## What does NOT ship

- **The harness / runner implementation** — the code that produced the records. Only its output ships.
- **The models** (`laya`, `decider-0.8b`, `decider-2b`, `decider-4b`) and their weights.
- **The as-audited stimulus fixture** (145,031 B, sha256
  `076164ac53c2c1aac130953345c481f88b51f4d6fb93d465c7430308a99b4796`) is withheld, **and so is any
  fixture copy**: its neutralised release ships with the companion note (Zenodo concept DOI
  `10.5281/zenodo.23463944`), not in this package.
- **The experiment note that defines the divergence axes** (9,347 B, sha256
  `ee680087634049b0d19d9b85d3a48e5392b6b1abd9b586eea44599f911bef14e`) — consulted as the definition
  of the divergence axes, but **not in the closure**: the cut ladder adds it to a full tree and the
  result is unchanged (exit `0` either way).

## Provenance — byte-identity, pinned by digest

| shipped path | source | source sha256 | shipped sha256 |
|---|---|---|---|
| `data/decision-variants.jsonl` | the records as produced by the harness (author-side copy; not distributed) | `c5ec44a799ddeb963f862fc5c054ddad6ef2fce6ad90edfafd7c1755ac4370e7` | identical |
| `data/l1-head-to-head.jsonl` | the records as produced by the harness (author-side copy; not distributed) | `6af0e0d8294cf4d7a20e2d8cb9bfe0c11ff70cc4c4b2792fcdedaf9246b2a1e7` | identical |
| `LICENSE` | the author's canonical release copy (not distributed) | `3d364676a91dc579954b585e9d3a3c9f0dc03b723715805cc9431f757ce6f900` | identical |
| `COMMERCIAL.md` | the author's canonical release copy (not distributed) | `d8762806bbbb53229345b625db77910f60f7c74b608c7f550797053da89f250c` | identical |
| `CONTRIBUTING.md` | the author's canonical release copy (not distributed) | `3b5e59622b3e4b7d4b9326101b615bcef484ddd80b31b78306ba416698a87996` | identical |
| `verify/recompute-claims.py` | authored for this release (the fixture section is optional — the fixture is not shipped) | — | — |
| `README.md` | authored for this release | — | — |
| `MANIFEST.json` | regenerated from the shipped tree by the deposit's manifest generator | — | — |

## CUTTING: how the closure was proved, and where it first breaks

Successively smaller copies of this tree were built and the claims re-derived in each (author-side
build tooling; not distributed). Removing the two fixture `.ts` files, or every record field except
`model`/`variant`/`id`/`picked_index`/`correct`/`decomposable`, leaves all six numbers intact
(exit `0`). The **first break is one single row**: deleting the last row of
`decision-variants.jsonl` takes the tree from 3,040 rows to 3,039 and the re-derivation exits `1`
with `FAIL  V3 binding == 494/1140`, `measured 476/1140`-class mismatches on the per-variant table.
Every one of the 3,040 rows is load-bearing; there is no slack row to trim. Dropping `correct`,
dropping `decomposable`, dropping V2/V3, or dropping either data file each also exits non-zero
(`KeyError: 'correct'`, `KeyError: 'decomposable'`, `FAIL V2 binding`, `FileNotFoundError`).

## Census result — reported, not silenced

A census of this tree (author-side tool; not distributed) reports **17 distinct identifiers / 6,887 occurrences**: 6,840 are the seven
case-kind tokens (`escalation`, `worker.class`, `context.package`, `memory.admission`, `acquisition`,
`capability.family`, `topology`) carried in `data/*.jsonl`. The 12 `MATERIALISE` occurrences that an
earlier draft inherited from the companion fixture are **not present**, because the fixture is not in
this package.

**Deliberately not neutralised.** The neutralisation pass (`--scheme neutral-tag`; author-side tooling,
not distributed) clears only two
of the seven (`escalation`, `topology`, both in its fixed `ROLES` list) at the cost of rewriting
`data/` and destroying the `identical_to_source: true` property that this package's validity rests
on; the remaining five are not in that scheme's vocabulary and would require **widening the vocabulary
list, which is forbidden**. Neutralisation was measured, not assumed: run over a copy it leaves every
number unchanged (V0 binding 476/1,140, l1 98/190), so it was rejected for breaking byte-identity
while buying partial clearance, not for moving a number. The census is therefore recorded here as a
known, inherited-and-own property of the shipped bytes rather than cleared by widening a gate.

## Licence

Released under the **PolyForm Noncommercial License 1.0.0** — see `LICENSE` (sha256 `3d364676a91dc579954b585e9d3a3c9f0dc03b723715805cc9431f757ce6f900`,
`Required Notice: Copyright 2026 Aswin-Ram-K`); the PolyForm body is unmodified.
**Any commercial use requires a paid commercial licence** — see `COMMERCIAL.md`.
